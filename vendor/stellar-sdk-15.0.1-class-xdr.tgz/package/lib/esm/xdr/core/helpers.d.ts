export declare function viewFor(bytes: Uint8Array): DataView;
export declare function paddingLength(length: number): number;
export declare function isPlainObject(value: unknown): value is Record<string, unknown>;
export declare function assertLength(value: number, name: string): void;
export declare function assertIntRange(value: unknown, min: number, max: number, path: string): asserts value is number;
export declare function assertBigIntRange(value: unknown, min: bigint, max: bigint, path: string): asserts value is bigint;
export declare function assertFiniteNumber(value: unknown, path: string): asserts value is number;
export declare function assertUint8Array(value: unknown, path: string): asserts value is Uint8Array;
export declare function assertArray(value: unknown, path: string): asserts value is unknown[];
