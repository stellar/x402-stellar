export declare const DEFAULT_MAX_DEPTH = 200;
export declare class Reader {
    #private;
    private readonly bytes;
    constructor(bytes: Uint8Array, maxDepth?: number);
    get offset(): number;
    get remaining(): number;
    enter(path: string): void;
    exit(): void;
    done(path: string): void;
    readBytes(length: number, path: string): Uint8Array;
    skipPadding(length: number, path: string): void;
    readInt32(path: string): number;
    readUint32(path: string): number;
    readBigInt64(path: string): bigint;
    readBigUint64(path: string): bigint;
    readFloat32(path: string): number;
    readFloat64(path: string): number;
}
