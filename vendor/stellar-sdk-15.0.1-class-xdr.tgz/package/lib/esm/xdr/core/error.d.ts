export declare class XdrError extends Error {
    constructor(message: string);
}
