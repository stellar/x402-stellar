import { type XdrType } from "../core/xdr-type.js";
export declare function double(): XdrType<number>;
