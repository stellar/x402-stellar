import type { Reader } from "../core/reader.js";
import type { Writer } from "../core/writer.js";
import { BaseType, type XdrType } from "../core/xdr-type.js";
declare class BoolType extends BaseType<boolean> {
    readonly kind = "bool";
    _read(reader: Reader, path: string): boolean;
    _write(value: boolean, writer: Writer, path: string): void;
}
export declare const BOOL_TYPE: BoolType;
export declare function bool(): XdrType<boolean>;
export {};
