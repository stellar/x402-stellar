import { type Infer, type XdrType } from "../core/xdr-type.js";
export declare function option<T extends XdrType<unknown>>(element: T): XdrType<Infer<T> | null>;
