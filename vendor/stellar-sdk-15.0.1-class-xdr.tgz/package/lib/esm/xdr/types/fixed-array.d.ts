import { type Infer, type XdrType } from "../core/xdr-type.js";
export declare function fixedArray<T extends XdrType<unknown>>(element: T, length: number): XdrType<Infer<T>[]>;
