import { type Infer, type XdrType } from "../core/xdr-type.js";
export declare function lazy<T extends XdrType<unknown>>(getSchema: () => T): XdrType<Infer<T>>;
