import type { Reader } from "../core/reader.js";
import type { Writer } from "../core/writer.js";
import { BaseType, type XdrType } from "../core/xdr-type.js";
export type EnumMember<Values extends Record<string, number>> = Values[keyof Values];
export type EnumName<Values extends Record<string, number>> = Extract<keyof Values, string>;
export type EnumSchema<Name extends string, Values extends Record<string, number>> = XdrType<EnumMember<Values>> & {
    readonly name: Name;
    readonly nameByValue: ReadonlyMap<number, EnumName<Values>>;
} & Values;
export declare class EnumType<Values extends Record<string, number>> extends BaseType<EnumMember<Values>> {
    #private;
    readonly kind = "enum";
    readonly nameByValue: ReadonlyMap<number, EnumName<Values>>;
    constructor(name: string, values: Values);
    _read(reader: Reader, path: string): EnumMember<Values>;
    _write(value: EnumMember<Values>, writer: Writer, path: string): void;
}
export declare function enumType<Name extends string, Values extends Record<string, number>>(name: Name, values: Values): EnumSchema<Name, Values>;
