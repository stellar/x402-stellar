import { type XdrType } from "../core/xdr-type.js";
export declare function opaque(length: number, name?: string): XdrType<Uint8Array>;
