import { type XdrType } from "../core/xdr-type.js";
export declare function int64(): XdrType<bigint>;
