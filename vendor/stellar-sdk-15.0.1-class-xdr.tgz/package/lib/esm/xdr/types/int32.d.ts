import { type XdrType } from "../core/xdr-type.js";
export declare function int32(): XdrType<number>;
