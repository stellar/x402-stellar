import { type XdrType } from "../core/xdr-type.js";
export declare function float(): XdrType<number>;
