import type { Reader } from "../core/reader.js";
import type { Writer } from "../core/writer.js";
import { type Infer, type XdrType } from "../core/xdr-type.js";
export declare function array<T extends XdrType<unknown>>(element: T, maxLength: number): XdrType<Infer<T>[]>;
export declare function readArray<T>(reader: Reader, length: number, element: XdrType<T>, path: string): T[];
export declare function writeArray<T>(values: T[], writer: Writer, element: XdrType<T>, path: string): void;
