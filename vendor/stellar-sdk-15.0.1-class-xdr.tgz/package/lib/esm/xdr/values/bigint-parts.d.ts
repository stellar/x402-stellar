export interface Int128Parts {
    readonly hi: bigint;
    readonly lo: bigint;
}
export interface Int256Parts {
    readonly hiHi: bigint;
    readonly hiLo: bigint;
    readonly loHi: bigint;
    readonly loLo: bigint;
}
export declare function bigIntTo128Parts(value: bigint, signed: boolean): Int128Parts;
export declare function partsTo128BigInt(parts: Int128Parts, signed: boolean): bigint;
export declare function bigIntTo256Parts(value: bigint, signed: boolean): Int256Parts;
export declare function partsTo256BigInt(parts: Int256Parts, signed: boolean): bigint;
