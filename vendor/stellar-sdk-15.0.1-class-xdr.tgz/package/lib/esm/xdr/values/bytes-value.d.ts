import { XdrValue } from "./xdr-value.js";
export type BytesEncoding = "hex" | "base64" | "ascii";
/**
 * Shared base for fixed-length and variable-length byte aliases (Hash, Signature, AssetCode4, ...).
 * Subclasses set `static readonly byteLength` (or override `validateLength`) and
 * `static readonly encoding` to control the `toJson()` representation.
 *
 * The `Tag` type parameter is a nominal-typing brand: subclasses pass a unique
 * string so structurally-identical aliases (e.g. `AssetCode4` vs `AssetCode12`)
 * are not silently assignable to each other.
 */
export declare abstract class BytesValue<Tag extends string = string> extends XdrValue {
    readonly __tag: Tag;
    readonly value: Uint8Array;
    constructor(value: Uint8Array | string);
    toXdrObject(): Uint8Array;
    toBytes(): Uint8Array;
}
