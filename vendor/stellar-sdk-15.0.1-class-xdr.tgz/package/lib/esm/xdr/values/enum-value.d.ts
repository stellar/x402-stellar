import { XdrValue } from "./xdr-value.js";
/**
 * Shared base for XDR enums.
 *
 * Subclasses use a private constructor and expose static singleton instances
 * for each enum member. The schema for an enum is the underlying int32 plus a
 * value→name mapping exposed via `static readonly schema.nameByValue`.
 *
 * `toJson()` is inherited from `XdrValue`, which walks the schema and applies
 * SEP-0051 naming (stripped + snake_cased), so members render the same way
 * whether they're at the top level or nested inside another type.
 */
export declare abstract class EnumValue<Name extends string> extends XdrValue {
    readonly name: Name;
    readonly value: number;
    protected constructor(name: Name, value: number);
    toXdrObject(): number;
}
export interface EnumSchemaView<Name extends string> {
    readonly nameByValue: ReadonlyMap<number, Name>;
}
type EnumInstances<Name extends string, Instance extends EnumValue<Name>> = Readonly<Record<Name, Instance>>;
export declare function enumFromValue<Name extends string, Instance extends EnumValue<Name>>(className: string, schema: EnumSchemaView<Name>, instances: EnumInstances<Name, Instance>, value: number): Instance;
export declare function enumFromName<Name extends string, Instance extends EnumValue<Name>>(className: string, instances: EnumInstances<Name, Instance>, name: Name): Instance;
export {};
