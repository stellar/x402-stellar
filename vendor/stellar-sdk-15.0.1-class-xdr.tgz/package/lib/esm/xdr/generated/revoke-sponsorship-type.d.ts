import { EnumValue } from "../values/enum-value.js";
export type RevokeSponsorshipTypeWire = number;
export type RevokeSponsorshipTypeName = "revokeSponsorshipLedgerEntry" | "revokeSponsorshipSigner";
/**
 * ```xdr
 * enum RevokeSponsorshipType
 * {
 *     REVOKE_SPONSORSHIP_LEDGER_ENTRY = 0,
 *     REVOKE_SPONSORSHIP_SIGNER = 1
 * };
 * ```
 */
export declare class RevokeSponsorshipType extends EnumValue<RevokeSponsorshipTypeName> {
    static readonly revokeSponsorshipLedgerEntry: RevokeSponsorshipType;
    static readonly revokeSponsorshipSigner: RevokeSponsorshipType;
    static readonly schema: import("../types/enum.js").EnumSchema<"RevokeSponsorshipType", {
        revokeSponsorshipLedgerEntry: number;
        revokeSponsorshipSigner: number;
    }>;
    static fromValue(value: number): RevokeSponsorshipType;
    static fromName(name: RevokeSponsorshipTypeName): RevokeSponsorshipType;
    static fromXdrObject(wire: number): RevokeSponsorshipType;
}
