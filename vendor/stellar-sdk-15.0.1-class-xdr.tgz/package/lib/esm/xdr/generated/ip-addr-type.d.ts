import { EnumValue } from "../values/enum-value.js";
export type IpAddrTypeWire = number;
export type IpAddrTypeName = "ipv4" | "ipv6";
/**
 * ```xdr
 * enum IPAddrType
 * {
 *     IPv4 = 0,
 *     IPv6 = 1
 * };
 * ```
 */
export declare class IpAddrType extends EnumValue<IpAddrTypeName> {
    static readonly ipv4: IpAddrType;
    static readonly ipv6: IpAddrType;
    static readonly schema: import("../types/enum.js").EnumSchema<"IpAddrType", {
        ipv4: number;
        ipv6: number;
    }>;
    static fromValue(value: number): IpAddrType;
    static fromName(name: IpAddrTypeName): IpAddrType;
    static fromXdrObject(wire: number): IpAddrType;
}
