import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { TransactionSetV1, type TransactionSetV1Wire } from "./transaction-set-v1.js";
export type GeneralizedTransactionSetWire = {
    v: 1;
    v1TxSet: TransactionSetV1Wire;
};
export type GeneralizedTransactionSetVariantName = "v1TxSet";
/**
 * ```xdr
 * union GeneralizedTransactionSet switch (int v)
 * {
 * // We consider the legacy TransactionSet to be v0.
 * case 1:
 *     TransactionSetV1 v1TxSet;
 * };
 * ```
 */
declare abstract class GeneralizedTransactionSetBase extends XdrValue {
    abstract readonly type: GeneralizedTransactionSetVariantName;
    static readonly schema: XdrType<GeneralizedTransactionSetWire>;
    static v1TxSet(v1TxSet: TransactionSetV1): GeneralizedTransactionSetV1txset;
    static fromXdrObject(wire: GeneralizedTransactionSetWire): GeneralizedTransactionSet;
    abstract toXdrObject(): GeneralizedTransactionSetWire;
}
export declare class GeneralizedTransactionSetV1txset extends GeneralizedTransactionSetBase {
    readonly type: "v1TxSet";
    readonly v1TxSet: TransactionSetV1;
    constructor(v1TxSet: TransactionSetV1);
    get value(): TransactionSetV1;
    toXdrObject(): Extract<GeneralizedTransactionSetWire, {
        v: 1;
    }>;
}
export type GeneralizedTransactionSet = GeneralizedTransactionSetV1txset;
export declare const GeneralizedTransactionSet: typeof GeneralizedTransactionSetBase;
export {};
