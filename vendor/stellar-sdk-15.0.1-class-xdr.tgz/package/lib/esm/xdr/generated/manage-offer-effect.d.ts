import { EnumValue } from "../values/enum-value.js";
export type ManageOfferEffectWire = number;
export type ManageOfferEffectName = "manageOfferCreated" | "manageOfferUpdated" | "manageOfferDeleted";
/**
 * ```xdr
 * enum ManageOfferEffect
 * {
 *     MANAGE_OFFER_CREATED = 0,
 *     MANAGE_OFFER_UPDATED = 1,
 *     MANAGE_OFFER_DELETED = 2
 * };
 * ```
 */
export declare class ManageOfferEffect extends EnumValue<ManageOfferEffectName> {
    static readonly manageOfferCreated: ManageOfferEffect;
    static readonly manageOfferUpdated: ManageOfferEffect;
    static readonly manageOfferDeleted: ManageOfferEffect;
    static readonly schema: import("../types/enum.js").EnumSchema<"ManageOfferEffect", {
        manageOfferCreated: number;
        manageOfferUpdated: number;
        manageOfferDeleted: number;
    }>;
    static fromValue(value: number): ManageOfferEffect;
    static fromName(name: ManageOfferEffectName): ManageOfferEffect;
    static fromXdrObject(wire: number): ManageOfferEffect;
}
