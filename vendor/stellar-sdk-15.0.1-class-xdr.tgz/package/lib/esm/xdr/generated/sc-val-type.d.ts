import { EnumValue } from "../values/enum-value.js";
export type ScValTypeWire = number;
export type ScValTypeName = "scvBool" | "scvVoid" | "scvError" | "scvU32" | "scvI32" | "scvU64" | "scvI64" | "scvTimepoint" | "scvDuration" | "scvU128" | "scvI128" | "scvU256" | "scvI256" | "scvBytes" | "scvString" | "scvSymbol" | "scvVec" | "scvMap" | "scvAddress" | "scvContractInstance" | "scvLedgerKeyContractInstance" | "scvLedgerKeyNonce";
/**
 * ```xdr
 * enum SCValType
 * {
 *     SCV_BOOL = 0,
 *     SCV_VOID = 1,
 *     SCV_ERROR = 2,
 *
 *     // 32 bits is the smallest type in WASM or XDR; no need for u8/u16.
 *     SCV_U32 = 3,
 *     SCV_I32 = 4,
 *
 *     // 64 bits is naturally supported by both WASM and XDR also.
 *     SCV_U64 = 5,
 *     SCV_I64 = 6,
 *
 *     // Time-related u64 subtypes with their own functions and formatting.
 *     SCV_TIMEPOINT = 7,
 *     SCV_DURATION = 8,
 *
 *     // 128 bits is naturally supported by Rust and we use it for Soroban
 *     // fixed-point arithmetic prices / balances / similar "quantities". These
 *     // are represented in XDR as a pair of 2 u64s.
 *     SCV_U128 = 9,
 *     SCV_I128 = 10,
 *
 *     // 256 bits is the size of sha256 output, ed25519 keys, and the EVM machine
 *     // word, so for interop use we include this even though it requires a small
 *     // amount of Rust guest and/or host library code.
 *     SCV_U256 = 11,
 *     SCV_I256 = 12,
 *
 *     // Bytes come in 3 flavors, 2 of which have meaningfully different
 *     // formatting and validity-checking / domain-restriction.
 *     SCV_BYTES = 13,
 *     SCV_STRING = 14,
 *     SCV_SYMBOL = 15,
 *
 *     // Vecs and maps are just polymorphic containers of other ScVals.
 *     SCV_VEC = 16,
 *     SCV_MAP = 17,
 *
 *     // Address is the universal identifier for contracts and classic
 *     // accounts.
 *     SCV_ADDRESS = 18,
 *
 *     // The following are the internal SCVal variants that are not
 *     // exposed to the contracts.
 *     SCV_CONTRACT_INSTANCE = 19,
 *
 *     // SCV_LEDGER_KEY_CONTRACT_INSTANCE and SCV_LEDGER_KEY_NONCE are unique
 *     // symbolic SCVals used as the key for ledger entries for a contract's
 *     // instance and an address' nonce, respectively.
 *     SCV_LEDGER_KEY_CONTRACT_INSTANCE = 20,
 *     SCV_LEDGER_KEY_NONCE = 21
 * };
 * ```
 */
export declare class ScValType extends EnumValue<ScValTypeName> {
    static readonly scvBool: ScValType;
    static readonly scvVoid: ScValType;
    static readonly scvError: ScValType;
    static readonly scvU32: ScValType;
    static readonly scvI32: ScValType;
    static readonly scvU64: ScValType;
    static readonly scvI64: ScValType;
    static readonly scvTimepoint: ScValType;
    static readonly scvDuration: ScValType;
    static readonly scvU128: ScValType;
    static readonly scvI128: ScValType;
    static readonly scvU256: ScValType;
    static readonly scvI256: ScValType;
    static readonly scvBytes: ScValType;
    static readonly scvString: ScValType;
    static readonly scvSymbol: ScValType;
    static readonly scvVec: ScValType;
    static readonly scvMap: ScValType;
    static readonly scvAddress: ScValType;
    static readonly scvContractInstance: ScValType;
    static readonly scvLedgerKeyContractInstance: ScValType;
    static readonly scvLedgerKeyNonce: ScValType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ScValType", {
        scvBool: number;
        scvVoid: number;
        scvError: number;
        scvU32: number;
        scvI32: number;
        scvU64: number;
        scvI64: number;
        scvTimepoint: number;
        scvDuration: number;
        scvU128: number;
        scvI128: number;
        scvU256: number;
        scvI256: number;
        scvBytes: number;
        scvString: number;
        scvSymbol: number;
        scvVec: number;
        scvMap: number;
        scvAddress: number;
        scvContractInstance: number;
        scvLedgerKeyContractInstance: number;
        scvLedgerKeyNonce: number;
    }>;
    static fromValue(value: number): ScValType;
    static fromName(name: ScValTypeName): ScValType;
    static fromXdrObject(wire: number): ScValType;
}
