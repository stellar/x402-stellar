import { EnumValue } from "../values/enum-value.js";
export type BumpSequenceResultCodeWire = number;
export type BumpSequenceResultCodeName = "bumpSequenceSuccess" | "bumpSequenceBadSeq";
/**
 * ```xdr
 * enum BumpSequenceResultCode
 * {
 *     // codes considered as "success" for the operation
 *     BUMP_SEQUENCE_SUCCESS = 0,
 *     // codes considered as "failure" for the operation
 *     BUMP_SEQUENCE_BAD_SEQ = -1 // `bumpTo` is not within bounds
 * };
 * ```
 */
export declare class BumpSequenceResultCode extends EnumValue<BumpSequenceResultCodeName> {
    static readonly bumpSequenceSuccess: BumpSequenceResultCode;
    static readonly bumpSequenceBadSeq: BumpSequenceResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"BumpSequenceResultCode", {
        bumpSequenceSuccess: number;
        bumpSequenceBadSeq: number;
    }>;
    static fromValue(value: number): BumpSequenceResultCode;
    static fromName(name: BumpSequenceResultCodeName): BumpSequenceResultCode;
    static fromXdrObject(wire: number): BumpSequenceResultCode;
}
