import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type PeerAddressIpWire = {
    type: 0;
    ipv4: Uint8Array;
} | {
    type: 1;
    ipv6: Uint8Array;
};
export type PeerAddressIpVariantName = "ipv4" | "ipv6";
/**
 * ```xdr
 * union switch (IPAddrType type)
 *     {
 *     case IPv4:
 *         opaque ipv4[4];
 *     case IPv6:
 *         opaque ipv6[16];
 *     }
 * ```
 */
declare abstract class PeerAddressIpBase extends XdrValue {
    abstract readonly type: PeerAddressIpVariantName;
    static readonly schema: XdrType<PeerAddressIpWire>;
    static ipv4(ipv4: Uint8Array): PeerAddressIpIpv4;
    static ipv6(ipv6: Uint8Array): PeerAddressIpIpv6;
    static fromXdrObject(wire: PeerAddressIpWire): PeerAddressIp;
    abstract toXdrObject(): PeerAddressIpWire;
}
export declare class PeerAddressIpIpv4 extends PeerAddressIpBase {
    readonly type: "ipv4";
    readonly ipv4: Uint8Array;
    constructor(ipv4: Uint8Array);
    get value(): Uint8Array;
    toXdrObject(): Extract<PeerAddressIpWire, {
        type: 0;
    }>;
}
export declare class PeerAddressIpIpv6 extends PeerAddressIpBase {
    readonly type: "ipv6";
    readonly ipv6: Uint8Array;
    constructor(ipv6: Uint8Array);
    get value(): Uint8Array;
    toXdrObject(): Extract<PeerAddressIpWire, {
        type: 1;
    }>;
}
export type PeerAddressIp = PeerAddressIpIpv4 | PeerAddressIpIpv6;
export declare const PeerAddressIp: typeof PeerAddressIpBase;
export {};
