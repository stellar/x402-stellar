import { PublicKey, type PublicKeyWire } from "./public-key.js";
export type AccountId = PublicKey;
export declare const AccountId: (abstract new () => {
    readonly type: import("./public-key.js").PublicKeyVariantName;
    toXdrObject(): PublicKeyWire;
    toXdr(): Uint8Array;
    toXdr(format: "raw"): Uint8Array;
    toXdr(format: "hex" | "base64"): string;
    toString(): string;
    toJson(): import("../index.js").JsonValue;
    equals(other: /*elided*/ any): boolean;
}) & {
    readonly schema: import("../core/xdr-type.js").XdrType<PublicKeyWire>;
    publicKeyTypeEd25519(ed25519: Uint8Array): import("./public-key.js").PublicKeyEd25519;
    fromXdrObject(wire: PublicKeyWire): PublicKey;
    fromXdr<Wire, Instance extends import("../index.js").XdrValue>(this: import("../index.js").XdrValueConstructor<Wire, Instance>, input: Uint8Array): Instance;
    fromXdr<Wire, Instance extends import("../index.js").XdrValue>(this: import("../index.js").XdrValueConstructor<Wire, Instance>, input: string, format: "hex" | "base64"): Instance;
    fromJson<Wire, Instance extends import("../index.js").XdrValue>(this: import("../index.js").XdrValueConstructor<Wire, Instance>, json: import("../index.js").JsonValue): Instance;
};
export type AccountIdWire = PublicKeyWire;
