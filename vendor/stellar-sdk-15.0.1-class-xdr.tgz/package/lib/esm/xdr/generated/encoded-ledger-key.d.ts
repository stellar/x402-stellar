import { BytesValue } from "../values/bytes-value.js";
export type EncodedLedgerKeyWire = Uint8Array;
/**
 * ```xdr
 * typedef opaque EncodedLedgerKey<>;
 * ```
 */
export declare class EncodedLedgerKey extends BytesValue<"EncodedLedgerKey"> {
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): EncodedLedgerKey;
}
