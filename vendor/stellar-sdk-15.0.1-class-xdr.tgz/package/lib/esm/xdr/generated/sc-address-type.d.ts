import { EnumValue } from "../values/enum-value.js";
export type ScAddressTypeWire = number;
export type ScAddressTypeName = "scAddressTypeAccount" | "scAddressTypeContract" | "scAddressTypeMuxedAccount" | "scAddressTypeClaimableBalance" | "scAddressTypeLiquidityPool";
/**
 * ```xdr
 * enum SCAddressType
 * {
 *     SC_ADDRESS_TYPE_ACCOUNT = 0,
 *     SC_ADDRESS_TYPE_CONTRACT = 1,
 *     SC_ADDRESS_TYPE_MUXED_ACCOUNT = 2,
 *     SC_ADDRESS_TYPE_CLAIMABLE_BALANCE = 3,
 *     SC_ADDRESS_TYPE_LIQUIDITY_POOL = 4
 * };
 * ```
 */
export declare class ScAddressType extends EnumValue<ScAddressTypeName> {
    static readonly scAddressTypeAccount: ScAddressType;
    static readonly scAddressTypeContract: ScAddressType;
    static readonly scAddressTypeMuxedAccount: ScAddressType;
    static readonly scAddressTypeClaimableBalance: ScAddressType;
    static readonly scAddressTypeLiquidityPool: ScAddressType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ScAddressType", {
        scAddressTypeAccount: number;
        scAddressTypeContract: number;
        scAddressTypeMuxedAccount: number;
        scAddressTypeClaimableBalance: number;
        scAddressTypeLiquidityPool: number;
    }>;
    static fromValue(value: number): ScAddressType;
    static fromName(name: ScAddressTypeName): ScAddressType;
    static fromXdrObject(wire: number): ScAddressType;
}
