import { EnumValue } from "../values/enum-value.js";
export type ContractCostTypeWire = number;
export type ContractCostTypeName = "wasminsnexec" | "memalloc" | "memcpy" | "memcmp" | "dispatchhostfunction" | "visitobject" | "valser" | "valdeser" | "computesha256hash" | "computeed25519pubkey" | "verifyed25519sig" | "vminstantiation" | "vmcachedinstantiation" | "invokevmfunction" | "computekeccak256hash" | "decodeecdsacurve256sig" | "recoverecdsasecp256k1key" | "int256addsub" | "int256mul" | "int256div" | "int256pow" | "int256shift" | "chacha20drawbytes" | "parsewasminstructions" | "parsewasmfunctions" | "parsewasmglobals" | "parsewasmtableentries" | "parsewasmtypes" | "parsewasmdatasegments" | "parsewasmelemsegments" | "parsewasmimports" | "parsewasmexports" | "parsewasmdatasegmentbytes" | "instantiatewasminstructions" | "instantiatewasmfunctions" | "instantiatewasmglobals" | "instantiatewasmtableentries" | "instantiatewasmtypes" | "instantiatewasmdatasegments" | "instantiatewasmelemsegments" | "instantiatewasmimports" | "instantiatewasmexports" | "instantiatewasmdatasegmentbytes" | "sec1decodepointuncompressed" | "verifyecdsasecp256r1sig" | "bls12381encodefp" | "bls12381decodefp" | "bls12381g1checkpointoncurve" | "bls12381g1checkpointinsubgroup" | "bls12381g2checkpointoncurve" | "bls12381g2checkpointinsubgroup" | "bls12381g1projectivetoaffine" | "bls12381g2projectivetoaffine" | "bls12381g1add" | "bls12381g1mul" | "bls12381g1msm" | "bls12381mapfptog1" | "bls12381hashtog1" | "bls12381g2add" | "bls12381g2mul" | "bls12381g2msm" | "bls12381mapfp2tog2" | "bls12381hashtog2" | "bls12381pairing" | "bls12381frfromu256" | "bls12381frtou256" | "bls12381fraddsub" | "bls12381frmul" | "bls12381frpow" | "bls12381frinv" | "bn254encodefp" | "bn254decodefp" | "bn254g1checkpointoncurve" | "bn254g2checkpointoncurve" | "bn254g2checkpointinsubgroup" | "bn254g1projectivetoaffine" | "bn254g1add" | "bn254g1mul" | "bn254pairing" | "bn254frfromu256" | "bn254frtou256" | "bn254fraddsub" | "bn254frmul" | "bn254frpow" | "bn254frinv" | "bn254g1msm";
/**
 * ```xdr
 * enum ContractCostType {
 *     // Cost of running 1 wasm instruction
 *     WasmInsnExec = 0,
 *     // Cost of allocating a slice of memory (in bytes)
 *     MemAlloc = 1,
 *     // Cost of copying a slice of bytes into a pre-allocated memory
 *     MemCpy = 2,
 *     // Cost of comparing two slices of memory
 *     MemCmp = 3,
 *     // Cost of a host function dispatch, not including the actual work done by
 *     // the function nor the cost of VM invocation machinary
 *     DispatchHostFunction = 4,
 *     // Cost of visiting a host object from the host object storage. Exists to
 *     // make sure some baseline cost coverage, i.e. repeatly visiting objects
 *     // by the guest will always incur some charges.
 *     VisitObject = 5,
 *     // Cost of serializing an xdr object to bytes
 *     ValSer = 6,
 *     // Cost of deserializing an xdr object from bytes
 *     ValDeser = 7,
 *     // Cost of computing the sha256 hash from bytes
 *     ComputeSha256Hash = 8,
 *     // Cost of computing the ed25519 pubkey from bytes
 *     ComputeEd25519PubKey = 9,
 *     // Cost of verifying ed25519 signature of a payload.
 *     VerifyEd25519Sig = 10,
 *     // Cost of instantiation a VM from wasm bytes code.
 *     VmInstantiation = 11,
 *     // Cost of instantiation a VM from a cached state.
 *     VmCachedInstantiation = 12,
 *     // Cost of invoking a function on the VM. If the function is a host function,
 *     // additional cost will be covered by `DispatchHostFunction`.
 *     InvokeVmFunction = 13,
 *     // Cost of computing a keccak256 hash from bytes.
 *     ComputeKeccak256Hash = 14,
 *     // Cost of decoding an ECDSA signature computed from a 256-bit prime modulus
 *     // curve (e.g. secp256k1 and secp256r1)
 *     DecodeEcdsaCurve256Sig = 15,
 *     // Cost of recovering an ECDSA secp256k1 key from a signature.
 *     RecoverEcdsaSecp256k1Key = 16,
 *     // Cost of int256 addition (`+`) and subtraction (`-`) operations
 *     Int256AddSub = 17,
 *     // Cost of int256 multiplication (`*`) operation
 *     Int256Mul = 18,
 *     // Cost of int256 division (`/`) operation
 *     Int256Div = 19,
 *     // Cost of int256 power (`exp`) operation
 *     Int256Pow = 20,
 *     // Cost of int256 shift (`shl`, `shr`) operation
 *     Int256Shift = 21,
 *     // Cost of drawing random bytes using a ChaCha20 PRNG
 *     ChaCha20DrawBytes = 22,
 *
 *     // Cost of parsing wasm bytes that only encode instructions.
 *     ParseWasmInstructions = 23,
 *     // Cost of parsing a known number of wasm functions.
 *     ParseWasmFunctions = 24,
 *     // Cost of parsing a known number of wasm globals.
 *     ParseWasmGlobals = 25,
 *     // Cost of parsing a known number of wasm table entries.
 *     ParseWasmTableEntries = 26,
 *     // Cost of parsing a known number of wasm types.
 *     ParseWasmTypes = 27,
 *     // Cost of parsing a known number of wasm data segments.
 *     ParseWasmDataSegments = 28,
 *     // Cost of parsing a known number of wasm element segments.
 *     ParseWasmElemSegments = 29,
 *     // Cost of parsing a known number of wasm imports.
 *     ParseWasmImports = 30,
 *     // Cost of parsing a known number of wasm exports.
 *     ParseWasmExports = 31,
 *     // Cost of parsing a known number of data segment bytes.
 *     ParseWasmDataSegmentBytes = 32,
 *
 *     // Cost of instantiating wasm bytes that only encode instructions.
 *     InstantiateWasmInstructions = 33,
 *     // Cost of instantiating a known number of wasm functions.
 *     InstantiateWasmFunctions = 34,
 *     // Cost of instantiating a known number of wasm globals.
 *     InstantiateWasmGlobals = 35,
 *     // Cost of instantiating a known number of wasm table entries.
 *     InstantiateWasmTableEntries = 36,
 *     // Cost of instantiating a known number of wasm types.
 *     InstantiateWasmTypes = 37,
 *     // Cost of instantiating a known number of wasm data segments.
 *     InstantiateWasmDataSegments = 38,
 *     // Cost of instantiating a known number of wasm element segments.
 *     InstantiateWasmElemSegments = 39,
 *     // Cost of instantiating a known number of wasm imports.
 *     InstantiateWasmImports = 40,
 *     // Cost of instantiating a known number of wasm exports.
 *     InstantiateWasmExports = 41,
 *     // Cost of instantiating a known number of data segment bytes.
 *     InstantiateWasmDataSegmentBytes = 42,
 *
 *     // Cost of decoding a bytes array representing an uncompressed SEC-1 encoded
 *     // point on a 256-bit elliptic curve
 *     Sec1DecodePointUncompressed = 43,
 *     // Cost of verifying an ECDSA Secp256r1 signature
 *     VerifyEcdsaSecp256r1Sig = 44,
 *
 *     // Cost of encoding a BLS12-381 Fp (base field element)
 *     Bls12381EncodeFp = 45,
 *     // Cost of decoding a BLS12-381 Fp (base field element)
 *     Bls12381DecodeFp = 46,
 *     // Cost of checking a G1 point lies on the curve
 *     Bls12381G1CheckPointOnCurve = 47,
 *     // Cost of checking a G1 point belongs to the correct subgroup
 *     Bls12381G1CheckPointInSubgroup = 48,
 *     // Cost of checking a G2 point lies on the curve
 *     Bls12381G2CheckPointOnCurve = 49,
 *     // Cost of checking a G2 point belongs to the correct subgroup
 *     Bls12381G2CheckPointInSubgroup = 50,
 *     // Cost of converting a BLS12-381 G1 point from projective to affine coordinates
 *     Bls12381G1ProjectiveToAffine = 51,
 *     // Cost of converting a BLS12-381 G2 point from projective to affine coordinates
 *     Bls12381G2ProjectiveToAffine = 52,
 *     // Cost of performing BLS12-381 G1 point addition
 *     Bls12381G1Add = 53,
 *     // Cost of performing BLS12-381 G1 scalar multiplication
 *     Bls12381G1Mul = 54,
 *     // Cost of performing BLS12-381 G1 multi-scalar multiplication (MSM)
 *     Bls12381G1Msm = 55,
 *     // Cost of mapping a BLS12-381 Fp field element to a G1 point
 *     Bls12381MapFpToG1 = 56,
 *     // Cost of hashing to a BLS12-381 G1 point
 *     Bls12381HashToG1 = 57,
 *     // Cost of performing BLS12-381 G2 point addition
 *     Bls12381G2Add = 58,
 *     // Cost of performing BLS12-381 G2 scalar multiplication
 *     Bls12381G2Mul = 59,
 *     // Cost of performing BLS12-381 G2 multi-scalar multiplication (MSM)
 *     Bls12381G2Msm = 60,
 *     // Cost of mapping a BLS12-381 Fp2 field element to a G2 point
 *     Bls12381MapFp2ToG2 = 61,
 *     // Cost of hashing to a BLS12-381 G2 point
 *     Bls12381HashToG2 = 62,
 *     // Cost of performing BLS12-381 pairing operation
 *     Bls12381Pairing = 63,
 *     // Cost of converting a BLS12-381 scalar element from U256
 *     Bls12381FrFromU256 = 64,
 *     // Cost of converting a BLS12-381 scalar element to U256
 *     Bls12381FrToU256 = 65,
 *     // Cost of performing BLS12-381 scalar element addition/subtraction
 *     Bls12381FrAddSub = 66,
 *     // Cost of performing BLS12-381 scalar element multiplication
 *     Bls12381FrMul = 67,
 *     // Cost of performing BLS12-381 scalar element exponentiation
 *     Bls12381FrPow = 68,
 *     // Cost of performing BLS12-381 scalar element inversion
 *     Bls12381FrInv = 69,
 *
 *     // Cost of encoding a BN254 Fp (base field element)
 *     Bn254EncodeFp = 70,
 *     // Cost of decoding a BN254 Fp (base field element)
 *     Bn254DecodeFp = 71,
 *     // Cost of checking a G1 point lies on the curve
 *     Bn254G1CheckPointOnCurve = 72,
 *     // Cost of checking a G2 point lies on the curve
 *     Bn254G2CheckPointOnCurve = 73,
 *     // Cost of checking a G2 point belongs to the correct subgroup
 *     Bn254G2CheckPointInSubgroup = 74,
 *     // Cost of converting a BN254 G1 point from projective to affine coordinates
 *     Bn254G1ProjectiveToAffine = 75,
 *     // Cost of performing BN254 G1 point addition
 *     Bn254G1Add = 76,
 *     // Cost of performing BN254 G1 scalar multiplication
 *     Bn254G1Mul = 77,
 *     // Cost of performing BN254 pairing operation
 *     Bn254Pairing = 78,
 *     // Cost of converting a BN254 scalar element from U256
 *     Bn254FrFromU256 = 79,
 *     // Cost of converting a BN254 scalar element to U256
 *     Bn254FrToU256 = 80,
 *     // // Cost of performing BN254 scalar element addition/subtraction
 *     Bn254FrAddSub = 81,
 *     // Cost of performing BN254 scalar element multiplication
 *     Bn254FrMul = 82,
 *     // Cost of performing BN254 scalar element exponentiation
 *     Bn254FrPow = 83,
 *      // Cost of performing BN254 scalar element inversion
 *     Bn254FrInv = 84,
 *     // Cost of performing BN254 G1 multi-scalar multiplication (MSM)
 *     Bn254G1Msm = 85
 * };
 * ```
 */
export declare class ContractCostType extends EnumValue<ContractCostTypeName> {
    static readonly wasminsnexec: ContractCostType;
    static readonly memalloc: ContractCostType;
    static readonly memcpy: ContractCostType;
    static readonly memcmp: ContractCostType;
    static readonly dispatchhostfunction: ContractCostType;
    static readonly visitobject: ContractCostType;
    static readonly valser: ContractCostType;
    static readonly valdeser: ContractCostType;
    static readonly computesha256hash: ContractCostType;
    static readonly computeed25519pubkey: ContractCostType;
    static readonly verifyed25519sig: ContractCostType;
    static readonly vminstantiation: ContractCostType;
    static readonly vmcachedinstantiation: ContractCostType;
    static readonly invokevmfunction: ContractCostType;
    static readonly computekeccak256hash: ContractCostType;
    static readonly decodeecdsacurve256sig: ContractCostType;
    static readonly recoverecdsasecp256k1key: ContractCostType;
    static readonly int256addsub: ContractCostType;
    static readonly int256mul: ContractCostType;
    static readonly int256div: ContractCostType;
    static readonly int256pow: ContractCostType;
    static readonly int256shift: ContractCostType;
    static readonly chacha20drawbytes: ContractCostType;
    static readonly parsewasminstructions: ContractCostType;
    static readonly parsewasmfunctions: ContractCostType;
    static readonly parsewasmglobals: ContractCostType;
    static readonly parsewasmtableentries: ContractCostType;
    static readonly parsewasmtypes: ContractCostType;
    static readonly parsewasmdatasegments: ContractCostType;
    static readonly parsewasmelemsegments: ContractCostType;
    static readonly parsewasmimports: ContractCostType;
    static readonly parsewasmexports: ContractCostType;
    static readonly parsewasmdatasegmentbytes: ContractCostType;
    static readonly instantiatewasminstructions: ContractCostType;
    static readonly instantiatewasmfunctions: ContractCostType;
    static readonly instantiatewasmglobals: ContractCostType;
    static readonly instantiatewasmtableentries: ContractCostType;
    static readonly instantiatewasmtypes: ContractCostType;
    static readonly instantiatewasmdatasegments: ContractCostType;
    static readonly instantiatewasmelemsegments: ContractCostType;
    static readonly instantiatewasmimports: ContractCostType;
    static readonly instantiatewasmexports: ContractCostType;
    static readonly instantiatewasmdatasegmentbytes: ContractCostType;
    static readonly sec1decodepointuncompressed: ContractCostType;
    static readonly verifyecdsasecp256r1sig: ContractCostType;
    static readonly bls12381encodefp: ContractCostType;
    static readonly bls12381decodefp: ContractCostType;
    static readonly bls12381g1checkpointoncurve: ContractCostType;
    static readonly bls12381g1checkpointinsubgroup: ContractCostType;
    static readonly bls12381g2checkpointoncurve: ContractCostType;
    static readonly bls12381g2checkpointinsubgroup: ContractCostType;
    static readonly bls12381g1projectivetoaffine: ContractCostType;
    static readonly bls12381g2projectivetoaffine: ContractCostType;
    static readonly bls12381g1add: ContractCostType;
    static readonly bls12381g1mul: ContractCostType;
    static readonly bls12381g1msm: ContractCostType;
    static readonly bls12381mapfptog1: ContractCostType;
    static readonly bls12381hashtog1: ContractCostType;
    static readonly bls12381g2add: ContractCostType;
    static readonly bls12381g2mul: ContractCostType;
    static readonly bls12381g2msm: ContractCostType;
    static readonly bls12381mapfp2tog2: ContractCostType;
    static readonly bls12381hashtog2: ContractCostType;
    static readonly bls12381pairing: ContractCostType;
    static readonly bls12381frfromu256: ContractCostType;
    static readonly bls12381frtou256: ContractCostType;
    static readonly bls12381fraddsub: ContractCostType;
    static readonly bls12381frmul: ContractCostType;
    static readonly bls12381frpow: ContractCostType;
    static readonly bls12381frinv: ContractCostType;
    static readonly bn254encodefp: ContractCostType;
    static readonly bn254decodefp: ContractCostType;
    static readonly bn254g1checkpointoncurve: ContractCostType;
    static readonly bn254g2checkpointoncurve: ContractCostType;
    static readonly bn254g2checkpointinsubgroup: ContractCostType;
    static readonly bn254g1projectivetoaffine: ContractCostType;
    static readonly bn254g1add: ContractCostType;
    static readonly bn254g1mul: ContractCostType;
    static readonly bn254pairing: ContractCostType;
    static readonly bn254frfromu256: ContractCostType;
    static readonly bn254frtou256: ContractCostType;
    static readonly bn254fraddsub: ContractCostType;
    static readonly bn254frmul: ContractCostType;
    static readonly bn254frpow: ContractCostType;
    static readonly bn254frinv: ContractCostType;
    static readonly bn254g1msm: ContractCostType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ContractCostType", {
        wasminsnexec: number;
        memalloc: number;
        memcpy: number;
        memcmp: number;
        dispatchhostfunction: number;
        visitobject: number;
        valser: number;
        valdeser: number;
        computesha256hash: number;
        computeed25519pubkey: number;
        verifyed25519sig: number;
        vminstantiation: number;
        vmcachedinstantiation: number;
        invokevmfunction: number;
        computekeccak256hash: number;
        decodeecdsacurve256sig: number;
        recoverecdsasecp256k1key: number;
        int256addsub: number;
        int256mul: number;
        int256div: number;
        int256pow: number;
        int256shift: number;
        chacha20drawbytes: number;
        parsewasminstructions: number;
        parsewasmfunctions: number;
        parsewasmglobals: number;
        parsewasmtableentries: number;
        parsewasmtypes: number;
        parsewasmdatasegments: number;
        parsewasmelemsegments: number;
        parsewasmimports: number;
        parsewasmexports: number;
        parsewasmdatasegmentbytes: number;
        instantiatewasminstructions: number;
        instantiatewasmfunctions: number;
        instantiatewasmglobals: number;
        instantiatewasmtableentries: number;
        instantiatewasmtypes: number;
        instantiatewasmdatasegments: number;
        instantiatewasmelemsegments: number;
        instantiatewasmimports: number;
        instantiatewasmexports: number;
        instantiatewasmdatasegmentbytes: number;
        sec1decodepointuncompressed: number;
        verifyecdsasecp256r1sig: number;
        bls12381encodefp: number;
        bls12381decodefp: number;
        bls12381g1checkpointoncurve: number;
        bls12381g1checkpointinsubgroup: number;
        bls12381g2checkpointoncurve: number;
        bls12381g2checkpointinsubgroup: number;
        bls12381g1projectivetoaffine: number;
        bls12381g2projectivetoaffine: number;
        bls12381g1add: number;
        bls12381g1mul: number;
        bls12381g1msm: number;
        bls12381mapfptog1: number;
        bls12381hashtog1: number;
        bls12381g2add: number;
        bls12381g2mul: number;
        bls12381g2msm: number;
        bls12381mapfp2tog2: number;
        bls12381hashtog2: number;
        bls12381pairing: number;
        bls12381frfromu256: number;
        bls12381frtou256: number;
        bls12381fraddsub: number;
        bls12381frmul: number;
        bls12381frpow: number;
        bls12381frinv: number;
        bn254encodefp: number;
        bn254decodefp: number;
        bn254g1checkpointoncurve: number;
        bn254g2checkpointoncurve: number;
        bn254g2checkpointinsubgroup: number;
        bn254g1projectivetoaffine: number;
        bn254g1add: number;
        bn254g1mul: number;
        bn254pairing: number;
        bn254frfromu256: number;
        bn254frtou256: number;
        bn254fraddsub: number;
        bn254frmul: number;
        bn254frpow: number;
        bn254frinv: number;
        bn254g1msm: number;
    }>;
    static fromValue(value: number): ContractCostType;
    static fromName(name: ContractCostTypeName): ContractCostType;
    static fromXdrObject(wire: number): ContractCostType;
}
