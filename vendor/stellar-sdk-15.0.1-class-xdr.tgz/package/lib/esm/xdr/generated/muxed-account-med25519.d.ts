import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export interface MuxedAccountMed25519Wire {
    id: bigint;
    ed25519: Uint8Array;
}
/**
 * ```xdr
 * struct
 *     {
 *         uint64 id;
 *         uint256 ed25519;
 *     }
 * ```
 */
export declare class MuxedAccountMed25519 extends XdrValue {
    readonly id: bigint;
    readonly ed25519: Uint8Array;
    static readonly schema: XdrType<MuxedAccountMed25519Wire>;
    constructor(input: {
        id: bigint;
        ed25519: Uint8Array;
    });
    toXdrObject(): MuxedAccountMed25519Wire;
    static fromXdrObject(wire: MuxedAccountMed25519Wire): MuxedAccountMed25519;
}
