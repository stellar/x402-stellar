import { EnumValue } from "../values/enum-value.js";
export type HostFunctionTypeWire = number;
export type HostFunctionTypeName = "hostFunctionTypeInvokeContract" | "hostFunctionTypeCreateContract" | "hostFunctionTypeUploadContractWasm" | "hostFunctionTypeCreateContractV2";
/**
 * ```xdr
 * enum HostFunctionType
 * {
 *     HOST_FUNCTION_TYPE_INVOKE_CONTRACT = 0,
 *     HOST_FUNCTION_TYPE_CREATE_CONTRACT = 1,
 *     HOST_FUNCTION_TYPE_UPLOAD_CONTRACT_WASM = 2,
 *     HOST_FUNCTION_TYPE_CREATE_CONTRACT_V2 = 3
 * };
 * ```
 */
export declare class HostFunctionType extends EnumValue<HostFunctionTypeName> {
    static readonly hostFunctionTypeInvokeContract: HostFunctionType;
    static readonly hostFunctionTypeCreateContract: HostFunctionType;
    static readonly hostFunctionTypeUploadContractWasm: HostFunctionType;
    static readonly hostFunctionTypeCreateContractV2: HostFunctionType;
    static readonly schema: import("../types/enum.js").EnumSchema<"HostFunctionType", {
        hostFunctionTypeInvokeContract: number;
        hostFunctionTypeCreateContract: number;
        hostFunctionTypeUploadContractWasm: number;
        hostFunctionTypeCreateContractV2: number;
    }>;
    static fromValue(value: number): HostFunctionType;
    static fromName(name: HostFunctionTypeName): HostFunctionType;
    static fromXdrObject(wire: number): HostFunctionType;
}
