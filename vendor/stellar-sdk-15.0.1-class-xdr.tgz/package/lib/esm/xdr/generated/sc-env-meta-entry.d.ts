import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { ScEnvMetaEntryInterfaceVersion, type ScEnvMetaEntryInterfaceVersionWire } from "./sc-env-meta-entry-interface-version.js";
export type ScEnvMetaEntryWire = {
    kind: 0;
    interfaceVersion: ScEnvMetaEntryInterfaceVersionWire;
};
export type ScEnvMetaEntryVariantName = "scEnvMetaKindInterfaceVersion";
/**
 * ```xdr
 * union SCEnvMetaEntry switch (SCEnvMetaKind kind)
 * {
 * case SC_ENV_META_KIND_INTERFACE_VERSION:
 *     struct {
 *         uint32 protocol;
 *         uint32 preRelease;
 *     } interfaceVersion;
 * };
 * ```
 */
declare abstract class ScEnvMetaEntryBase extends XdrValue {
    abstract readonly type: ScEnvMetaEntryVariantName;
    static readonly schema: XdrType<ScEnvMetaEntryWire>;
    static scEnvMetaKindInterfaceVersion(interfaceVersion: ScEnvMetaEntryInterfaceVersion): ScEnvMetaEntryInterfaceVersionArm;
    static fromXdrObject(wire: ScEnvMetaEntryWire): ScEnvMetaEntry;
    abstract toXdrObject(): ScEnvMetaEntryWire;
}
export declare class ScEnvMetaEntryInterfaceVersionArm extends ScEnvMetaEntryBase {
    readonly type: "scEnvMetaKindInterfaceVersion";
    readonly interfaceVersion: ScEnvMetaEntryInterfaceVersion;
    constructor(interfaceVersion: ScEnvMetaEntryInterfaceVersion);
    get value(): ScEnvMetaEntryInterfaceVersion;
    toXdrObject(): Extract<ScEnvMetaEntryWire, {
        kind: 0;
    }>;
}
export type ScEnvMetaEntry = ScEnvMetaEntryInterfaceVersionArm;
export declare const ScEnvMetaEntry: typeof ScEnvMetaEntryBase;
export {};
