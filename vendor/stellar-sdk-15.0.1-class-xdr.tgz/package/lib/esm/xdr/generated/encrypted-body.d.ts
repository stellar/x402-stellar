import { BytesValue } from "../values/bytes-value.js";
export type EncryptedBodyWire = Uint8Array;
/**
 * ```xdr
 * typedef opaque EncryptedBody<64000>;
 * ```
 */
export declare class EncryptedBody extends BytesValue<"EncryptedBody"> {
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): EncryptedBody;
}
