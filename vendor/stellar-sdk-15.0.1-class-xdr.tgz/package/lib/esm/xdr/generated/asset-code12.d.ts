import { BytesValue } from "../values/bytes-value.js";
export type AssetCode12Wire = Uint8Array;
/**
 * ```xdr
 * typedef opaque AssetCode12[12];
 * ```
 */
export declare class AssetCode12 extends BytesValue<"AssetCode12"> {
    static readonly byteLength = 12;
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): AssetCode12;
}
