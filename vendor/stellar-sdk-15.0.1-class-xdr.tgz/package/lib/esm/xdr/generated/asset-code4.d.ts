import { BytesValue } from "../values/bytes-value.js";
export type AssetCode4Wire = Uint8Array;
/**
 * ```xdr
 * typedef opaque AssetCode4[4];
 * ```
 */
export declare class AssetCode4 extends BytesValue<"AssetCode4"> {
    static readonly byteLength = 4;
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): AssetCode4;
}
