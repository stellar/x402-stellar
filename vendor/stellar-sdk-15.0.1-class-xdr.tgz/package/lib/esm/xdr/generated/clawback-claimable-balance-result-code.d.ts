import { EnumValue } from "../values/enum-value.js";
export type ClawbackClaimableBalanceResultCodeWire = number;
export type ClawbackClaimableBalanceResultCodeName = "clawbackClaimableBalanceSuccess" | "clawbackClaimableBalanceDoesNotExist" | "clawbackClaimableBalanceNotIssuer" | "clawbackClaimableBalanceNotClawbackEnabled";
/**
 * ```xdr
 * enum ClawbackClaimableBalanceResultCode
 * {
 *     // codes considered as "success" for the operation
 *     CLAWBACK_CLAIMABLE_BALANCE_SUCCESS = 0,
 *
 *     // codes considered as "failure" for the operation
 *     CLAWBACK_CLAIMABLE_BALANCE_DOES_NOT_EXIST = -1,
 *     CLAWBACK_CLAIMABLE_BALANCE_NOT_ISSUER = -2,
 *     CLAWBACK_CLAIMABLE_BALANCE_NOT_CLAWBACK_ENABLED = -3
 * };
 * ```
 */
export declare class ClawbackClaimableBalanceResultCode extends EnumValue<ClawbackClaimableBalanceResultCodeName> {
    static readonly clawbackClaimableBalanceSuccess: ClawbackClaimableBalanceResultCode;
    static readonly clawbackClaimableBalanceDoesNotExist: ClawbackClaimableBalanceResultCode;
    static readonly clawbackClaimableBalanceNotIssuer: ClawbackClaimableBalanceResultCode;
    static readonly clawbackClaimableBalanceNotClawbackEnabled: ClawbackClaimableBalanceResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"ClawbackClaimableBalanceResultCode", {
        clawbackClaimableBalanceSuccess: number;
        clawbackClaimableBalanceDoesNotExist: number;
        clawbackClaimableBalanceNotIssuer: number;
        clawbackClaimableBalanceNotClawbackEnabled: number;
    }>;
    static fromValue(value: number): ClawbackClaimableBalanceResultCode;
    static fromName(name: ClawbackClaimableBalanceResultCodeName): ClawbackClaimableBalanceResultCode;
    static fromXdrObject(wire: number): ClawbackClaimableBalanceResultCode;
}
