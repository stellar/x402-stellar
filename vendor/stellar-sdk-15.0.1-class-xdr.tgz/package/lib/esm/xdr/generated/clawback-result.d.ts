import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type ClawbackResultWire = {
    code: 0;
} | {
    code: -1;
} | {
    code: -2;
} | {
    code: -3;
} | {
    code: -4;
};
export type ClawbackResultVariantName = "clawbackSuccess" | "clawbackMalformed" | "clawbackNotClawbackEnabled" | "clawbackNoTrust" | "clawbackUnderfunded";
/**
 * ```xdr
 * union ClawbackResult switch (ClawbackResultCode code)
 * {
 * case CLAWBACK_SUCCESS:
 *     void;
 * case CLAWBACK_MALFORMED:
 * case CLAWBACK_NOT_CLAWBACK_ENABLED:
 * case CLAWBACK_NO_TRUST:
 * case CLAWBACK_UNDERFUNDED:
 *     void;
 * };
 * ```
 */
declare abstract class ClawbackResultBase extends XdrValue {
    abstract readonly type: ClawbackResultVariantName;
    static readonly schema: XdrType<ClawbackResultWire>;
    static clawbackSuccess(): ClawbackResultSuccess;
    static clawbackMalformed(): ClawbackResultMalformed;
    static clawbackNotClawbackEnabled(): ClawbackResultNotClawbackEnabled;
    static clawbackNoTrust(): ClawbackResultNoTrust;
    static clawbackUnderfunded(): ClawbackResultUnderfunded;
    static fromXdrObject(wire: ClawbackResultWire): ClawbackResult;
    abstract toXdrObject(): ClawbackResultWire;
}
export declare class ClawbackResultSuccess extends ClawbackResultBase {
    readonly type: "clawbackSuccess";
    toXdrObject(): Extract<ClawbackResultWire, {
        code: 0;
    }>;
}
export declare class ClawbackResultMalformed extends ClawbackResultBase {
    readonly type: "clawbackMalformed";
    toXdrObject(): Extract<ClawbackResultWire, {
        code: -1;
    }>;
}
export declare class ClawbackResultNotClawbackEnabled extends ClawbackResultBase {
    readonly type: "clawbackNotClawbackEnabled";
    toXdrObject(): Extract<ClawbackResultWire, {
        code: -2;
    }>;
}
export declare class ClawbackResultNoTrust extends ClawbackResultBase {
    readonly type: "clawbackNoTrust";
    toXdrObject(): Extract<ClawbackResultWire, {
        code: -3;
    }>;
}
export declare class ClawbackResultUnderfunded extends ClawbackResultBase {
    readonly type: "clawbackUnderfunded";
    toXdrObject(): Extract<ClawbackResultWire, {
        code: -4;
    }>;
}
export type ClawbackResult = ClawbackResultSuccess | ClawbackResultMalformed | ClawbackResultNotClawbackEnabled | ClawbackResultNoTrust | ClawbackResultUnderfunded;
export declare const ClawbackResult: typeof ClawbackResultBase;
export {};
