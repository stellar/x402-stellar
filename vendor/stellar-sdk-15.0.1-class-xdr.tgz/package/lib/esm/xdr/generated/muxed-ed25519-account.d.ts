import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export interface MuxedEd25519AccountWire {
    id: bigint;
    ed25519: Uint8Array;
}
/**
 * ```xdr
 * struct MuxedEd25519Account
 * {
 *     uint64 id;
 *     uint256 ed25519;
 * };
 * ```
 */
export declare class MuxedEd25519Account extends XdrValue {
    readonly id: bigint;
    readonly ed25519: Uint8Array;
    static readonly schema: XdrType<MuxedEd25519AccountWire>;
    constructor(input: {
        id: bigint;
        ed25519: Uint8Array;
    });
    toXdrObject(): MuxedEd25519AccountWire;
    static fromXdrObject(wire: MuxedEd25519AccountWire): MuxedEd25519Account;
}
