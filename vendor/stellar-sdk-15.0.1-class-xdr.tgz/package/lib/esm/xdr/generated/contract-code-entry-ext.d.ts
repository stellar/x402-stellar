import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { ContractCodeEntryV1, type ContractCodeEntryV1Wire } from "./contract-code-entry-v1.js";
export type ContractCodeEntryExtWire = {
    v: 0;
} | {
    v: 1;
    v1: ContractCodeEntryV1Wire;
};
export type ContractCodeEntryExtVariantName = "v0" | "v1";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *         case 0:
 *             void;
 *         case 1:
 *             struct
 *             {
 *                 ExtensionPoint ext;
 *                 ContractCodeCostInputs costInputs;
 *             } v1;
 *     }
 * ```
 */
declare abstract class ContractCodeEntryExtBase extends XdrValue {
    abstract readonly type: ContractCodeEntryExtVariantName;
    static readonly schema: XdrType<ContractCodeEntryExtWire>;
    static v0(): ContractCodeEntryExtV0;
    static v1(v1: ContractCodeEntryV1): ContractCodeEntryExtV1;
    static fromXdrObject(wire: ContractCodeEntryExtWire): ContractCodeEntryExt;
    abstract toXdrObject(): ContractCodeEntryExtWire;
}
export declare class ContractCodeEntryExtV0 extends ContractCodeEntryExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<ContractCodeEntryExtWire, {
        v: 0;
    }>;
}
export declare class ContractCodeEntryExtV1 extends ContractCodeEntryExtBase {
    readonly type: "v1";
    readonly v1: ContractCodeEntryV1;
    constructor(v1: ContractCodeEntryV1);
    get value(): ContractCodeEntryV1;
    toXdrObject(): Extract<ContractCodeEntryExtWire, {
        v: 1;
    }>;
}
export type ContractCodeEntryExt = ContractCodeEntryExtV0 | ContractCodeEntryExtV1;
export declare const ContractCodeEntryExt: typeof ContractCodeEntryExtBase;
export {};
