import { EnumValue } from "../values/enum-value.js";
export type ErrorCodeWire = number;
export type ErrorCodeName = "errMisc" | "errData" | "errConf" | "errAuth" | "errLoad";
/**
 * ```xdr
 * enum ErrorCode
 * {
 *     ERR_MISC = 0, // Unspecific error
 *     ERR_DATA = 1, // Malformed data
 *     ERR_CONF = 2, // Misconfiguration error
 *     ERR_AUTH = 3, // Authentication failure
 *     ERR_LOAD = 4  // System overloaded
 * };
 * ```
 */
export declare class ErrorCode extends EnumValue<ErrorCodeName> {
    static readonly errMisc: ErrorCode;
    static readonly errData: ErrorCode;
    static readonly errConf: ErrorCode;
    static readonly errAuth: ErrorCode;
    static readonly errLoad: ErrorCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"ErrorCode", {
        errMisc: number;
        errData: number;
        errConf: number;
        errAuth: number;
        errLoad: number;
    }>;
    static fromValue(value: number): ErrorCode;
    static fromName(name: ErrorCodeName): ErrorCode;
    static fromXdrObject(wire: number): ErrorCode;
}
