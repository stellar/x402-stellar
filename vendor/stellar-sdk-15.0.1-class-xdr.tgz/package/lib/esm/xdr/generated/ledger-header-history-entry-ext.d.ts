import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type LedgerHeaderHistoryEntryExtWire = {
    v: 0;
};
export type LedgerHeaderHistoryEntryExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class LedgerHeaderHistoryEntryExtBase extends XdrValue {
    abstract readonly type: LedgerHeaderHistoryEntryExtVariantName;
    static readonly schema: XdrType<LedgerHeaderHistoryEntryExtWire>;
    static v0(): LedgerHeaderHistoryEntryExtV0;
    static fromXdrObject(wire: LedgerHeaderHistoryEntryExtWire): LedgerHeaderHistoryEntryExt;
    abstract toXdrObject(): LedgerHeaderHistoryEntryExtWire;
}
export declare class LedgerHeaderHistoryEntryExtV0 extends LedgerHeaderHistoryEntryExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<LedgerHeaderHistoryEntryExtWire, {
        v: 0;
    }>;
}
export type LedgerHeaderHistoryEntryExt = LedgerHeaderHistoryEntryExtV0;
export declare const LedgerHeaderHistoryEntryExt: typeof LedgerHeaderHistoryEntryExtBase;
export {};
