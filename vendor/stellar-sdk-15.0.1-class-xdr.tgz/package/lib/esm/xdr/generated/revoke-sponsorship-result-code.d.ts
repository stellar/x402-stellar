import { EnumValue } from "../values/enum-value.js";
export type RevokeSponsorshipResultCodeWire = number;
export type RevokeSponsorshipResultCodeName = "revokeSponsorshipSuccess" | "revokeSponsorshipDoesNotExist" | "revokeSponsorshipNotSponsor" | "revokeSponsorshipLowReserve" | "revokeSponsorshipOnlyTransferable" | "revokeSponsorshipMalformed";
/**
 * ```xdr
 * enum RevokeSponsorshipResultCode
 * {
 *     // codes considered as "success" for the operation
 *     REVOKE_SPONSORSHIP_SUCCESS = 0,
 *
 *     // codes considered as "failure" for the operation
 *     REVOKE_SPONSORSHIP_DOES_NOT_EXIST = -1,
 *     REVOKE_SPONSORSHIP_NOT_SPONSOR = -2,
 *     REVOKE_SPONSORSHIP_LOW_RESERVE = -3,
 *     REVOKE_SPONSORSHIP_ONLY_TRANSFERABLE = -4,
 *     REVOKE_SPONSORSHIP_MALFORMED = -5
 * };
 * ```
 */
export declare class RevokeSponsorshipResultCode extends EnumValue<RevokeSponsorshipResultCodeName> {
    static readonly revokeSponsorshipSuccess: RevokeSponsorshipResultCode;
    static readonly revokeSponsorshipDoesNotExist: RevokeSponsorshipResultCode;
    static readonly revokeSponsorshipNotSponsor: RevokeSponsorshipResultCode;
    static readonly revokeSponsorshipLowReserve: RevokeSponsorshipResultCode;
    static readonly revokeSponsorshipOnlyTransferable: RevokeSponsorshipResultCode;
    static readonly revokeSponsorshipMalformed: RevokeSponsorshipResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"RevokeSponsorshipResultCode", {
        revokeSponsorshipSuccess: number;
        revokeSponsorshipDoesNotExist: number;
        revokeSponsorshipNotSponsor: number;
        revokeSponsorshipLowReserve: number;
        revokeSponsorshipOnlyTransferable: number;
        revokeSponsorshipMalformed: number;
    }>;
    static fromValue(value: number): RevokeSponsorshipResultCode;
    static fromName(name: RevokeSponsorshipResultCodeName): RevokeSponsorshipResultCode;
    static fromXdrObject(wire: number): RevokeSponsorshipResultCode;
}
