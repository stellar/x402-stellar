import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type InnerTransactionResultExtWire = {
    v: 0;
};
export type InnerTransactionResultExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class InnerTransactionResultExtBase extends XdrValue {
    abstract readonly type: InnerTransactionResultExtVariantName;
    static readonly schema: XdrType<InnerTransactionResultExtWire>;
    static v0(): InnerTransactionResultExtV0;
    static fromXdrObject(wire: InnerTransactionResultExtWire): InnerTransactionResultExt;
    abstract toXdrObject(): InnerTransactionResultExtWire;
}
export declare class InnerTransactionResultExtV0 extends InnerTransactionResultExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<InnerTransactionResultExtWire, {
        v: 0;
    }>;
}
export type InnerTransactionResultExt = InnerTransactionResultExtV0;
export declare const InnerTransactionResultExt: typeof InnerTransactionResultExtBase;
export {};
