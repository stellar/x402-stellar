import { EnumValue } from "../values/enum-value.js";
export type ContractExecutableTypeWire = number;
export type ContractExecutableTypeName = "contractExecutableWasm" | "contractExecutableStellarAsset";
/**
 * ```xdr
 * enum ContractExecutableType
 * {
 *     CONTRACT_EXECUTABLE_WASM = 0,
 *     CONTRACT_EXECUTABLE_STELLAR_ASSET = 1
 * };
 * ```
 */
export declare class ContractExecutableType extends EnumValue<ContractExecutableTypeName> {
    static readonly contractExecutableWasm: ContractExecutableType;
    static readonly contractExecutableStellarAsset: ContractExecutableType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ContractExecutableType", {
        contractExecutableWasm: number;
        contractExecutableStellarAsset: number;
    }>;
    static fromValue(value: number): ContractExecutableType;
    static fromName(name: ContractExecutableTypeName): ContractExecutableType;
    static fromXdrObject(wire: number): ContractExecutableType;
}
