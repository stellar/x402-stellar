import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type PublicKeyWire = {
    type: 0;
    ed25519: Uint8Array;
};
export type PublicKeyVariantName = "publicKeyTypeEd25519";
/**
 * ```xdr
 * union PublicKey switch (PublicKeyType type)
 * {
 * case PUBLIC_KEY_TYPE_ED25519:
 *     uint256 ed25519;
 * };
 * ```
 */
declare abstract class PublicKeyBase extends XdrValue {
    abstract readonly type: PublicKeyVariantName;
    static readonly schema: XdrType<PublicKeyWire>;
    static publicKeyTypeEd25519(ed25519: Uint8Array): PublicKeyEd25519;
    static fromXdrObject(wire: PublicKeyWire): PublicKey;
    abstract toXdrObject(): PublicKeyWire;
}
export declare class PublicKeyEd25519 extends PublicKeyBase {
    readonly type: "publicKeyTypeEd25519";
    readonly ed25519: Uint8Array;
    constructor(ed25519: Uint8Array);
    get value(): Uint8Array;
    toXdrObject(): Extract<PublicKeyWire, {
        type: 0;
    }>;
}
export type PublicKey = PublicKeyEd25519;
export declare const PublicKey: typeof PublicKeyBase;
export {};
