import { EnumValue } from "../values/enum-value.js";
export type OperationResultCodeWire = number;
export type OperationResultCodeName = "opInner" | "opBadAuth" | "opNoAccount" | "opNotSupported" | "opTooManySubentries" | "opExceededWorkLimit" | "opTooManySponsoring";
/**
 * ```xdr
 * enum OperationResultCode
 * {
 *     opINNER = 0, // inner object result is valid
 *
 *     opBAD_AUTH = -1,            // too few valid signatures / wrong network
 *     opNO_ACCOUNT = -2,          // source account was not found
 *     opNOT_SUPPORTED = -3,       // operation not supported at this time
 *     opTOO_MANY_SUBENTRIES = -4, // max number of subentries already reached
 *     opEXCEEDED_WORK_LIMIT = -5, // operation did too much work
 *     opTOO_MANY_SPONSORING = -6  // account is sponsoring too many entries
 * };
 * ```
 */
export declare class OperationResultCode extends EnumValue<OperationResultCodeName> {
    static readonly opInner: OperationResultCode;
    static readonly opBadAuth: OperationResultCode;
    static readonly opNoAccount: OperationResultCode;
    static readonly opNotSupported: OperationResultCode;
    static readonly opTooManySubentries: OperationResultCode;
    static readonly opExceededWorkLimit: OperationResultCode;
    static readonly opTooManySponsoring: OperationResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"OperationResultCode", {
        opInner: number;
        opBadAuth: number;
        opNoAccount: number;
        opNotSupported: number;
        opTooManySubentries: number;
        opExceededWorkLimit: number;
        opTooManySponsoring: number;
    }>;
    static fromValue(value: number): OperationResultCode;
    static fromName(name: OperationResultCodeName): OperationResultCode;
    static fromXdrObject(wire: number): OperationResultCode;
}
