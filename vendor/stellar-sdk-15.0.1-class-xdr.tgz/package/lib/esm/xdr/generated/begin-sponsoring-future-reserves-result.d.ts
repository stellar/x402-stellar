import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type BeginSponsoringFutureReservesResultWire = {
    code: 0;
} | {
    code: -1;
} | {
    code: -2;
} | {
    code: -3;
};
export type BeginSponsoringFutureReservesResultVariantName = "beginSponsoringFutureReservesSuccess" | "beginSponsoringFutureReservesMalformed" | "beginSponsoringFutureReservesAlreadySponsored" | "beginSponsoringFutureReservesRecursive";
/**
 * ```xdr
 * union BeginSponsoringFutureReservesResult switch (
 *     BeginSponsoringFutureReservesResultCode code)
 * {
 * case BEGIN_SPONSORING_FUTURE_RESERVES_SUCCESS:
 *     void;
 * case BEGIN_SPONSORING_FUTURE_RESERVES_MALFORMED:
 * case BEGIN_SPONSORING_FUTURE_RESERVES_ALREADY_SPONSORED:
 * case BEGIN_SPONSORING_FUTURE_RESERVES_RECURSIVE:
 *     void;
 * };
 * ```
 */
declare abstract class BeginSponsoringFutureReservesResultBase extends XdrValue {
    abstract readonly type: BeginSponsoringFutureReservesResultVariantName;
    static readonly schema: XdrType<BeginSponsoringFutureReservesResultWire>;
    static beginSponsoringFutureReservesSuccess(): BeginSponsoringFutureReservesResultSuccess;
    static beginSponsoringFutureReservesMalformed(): BeginSponsoringFutureReservesResultMalformed;
    static beginSponsoringFutureReservesAlreadySponsored(): BeginSponsoringFutureReservesResultAlreadySponsored;
    static beginSponsoringFutureReservesRecursive(): BeginSponsoringFutureReservesResultRecursive;
    static fromXdrObject(wire: BeginSponsoringFutureReservesResultWire): BeginSponsoringFutureReservesResult;
    abstract toXdrObject(): BeginSponsoringFutureReservesResultWire;
}
export declare class BeginSponsoringFutureReservesResultSuccess extends BeginSponsoringFutureReservesResultBase {
    readonly type: "beginSponsoringFutureReservesSuccess";
    toXdrObject(): Extract<BeginSponsoringFutureReservesResultWire, {
        code: 0;
    }>;
}
export declare class BeginSponsoringFutureReservesResultMalformed extends BeginSponsoringFutureReservesResultBase {
    readonly type: "beginSponsoringFutureReservesMalformed";
    toXdrObject(): Extract<BeginSponsoringFutureReservesResultWire, {
        code: -1;
    }>;
}
export declare class BeginSponsoringFutureReservesResultAlreadySponsored extends BeginSponsoringFutureReservesResultBase {
    readonly type: "beginSponsoringFutureReservesAlreadySponsored";
    toXdrObject(): Extract<BeginSponsoringFutureReservesResultWire, {
        code: -2;
    }>;
}
export declare class BeginSponsoringFutureReservesResultRecursive extends BeginSponsoringFutureReservesResultBase {
    readonly type: "beginSponsoringFutureReservesRecursive";
    toXdrObject(): Extract<BeginSponsoringFutureReservesResultWire, {
        code: -3;
    }>;
}
export type BeginSponsoringFutureReservesResult = BeginSponsoringFutureReservesResultSuccess | BeginSponsoringFutureReservesResultMalformed | BeginSponsoringFutureReservesResultAlreadySponsored | BeginSponsoringFutureReservesResultRecursive;
export declare const BeginSponsoringFutureReservesResult: typeof BeginSponsoringFutureReservesResultBase;
export {};
