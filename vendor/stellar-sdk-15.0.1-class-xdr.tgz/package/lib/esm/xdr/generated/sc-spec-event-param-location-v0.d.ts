import { EnumValue } from "../values/enum-value.js";
export type ScSpecEventParamLocationV0Wire = number;
export type ScSpecEventParamLocationV0Name = "scSpecEventParamLocationData" | "scSpecEventParamLocationTopicList";
/**
 * ```xdr
 * enum SCSpecEventParamLocationV0
 * {
 *     SC_SPEC_EVENT_PARAM_LOCATION_DATA = 0,
 *     SC_SPEC_EVENT_PARAM_LOCATION_TOPIC_LIST = 1
 * };
 * ```
 */
export declare class ScSpecEventParamLocationV0 extends EnumValue<ScSpecEventParamLocationV0Name> {
    static readonly scSpecEventParamLocationData: ScSpecEventParamLocationV0;
    static readonly scSpecEventParamLocationTopicList: ScSpecEventParamLocationV0;
    static readonly schema: import("../types/enum.js").EnumSchema<"ScSpecEventParamLocationV0", {
        scSpecEventParamLocationData: number;
        scSpecEventParamLocationTopicList: number;
    }>;
    static fromValue(value: number): ScSpecEventParamLocationV0;
    static fromName(name: ScSpecEventParamLocationV0Name): ScSpecEventParamLocationV0;
    static fromXdrObject(wire: number): ScSpecEventParamLocationV0;
}
