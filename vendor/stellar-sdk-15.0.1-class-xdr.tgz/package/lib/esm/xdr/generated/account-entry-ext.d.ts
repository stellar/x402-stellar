import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { AccountEntryExtensionV1, type AccountEntryExtensionV1Wire } from "./account-entry-extension-v1.js";
export type AccountEntryExtWire = {
    v: 0;
} | {
    v: 1;
    v1: AccountEntryExtensionV1Wire;
};
export type AccountEntryExtVariantName = "v0" | "v1";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     case 1:
 *         AccountEntryExtensionV1 v1;
 *     }
 * ```
 */
declare abstract class AccountEntryExtBase extends XdrValue {
    abstract readonly type: AccountEntryExtVariantName;
    static readonly schema: XdrType<AccountEntryExtWire>;
    static v0(): AccountEntryExtV0;
    static v1(v1: AccountEntryExtensionV1): AccountEntryExtV1;
    static fromXdrObject(wire: AccountEntryExtWire): AccountEntryExt;
    abstract toXdrObject(): AccountEntryExtWire;
}
export declare class AccountEntryExtV0 extends AccountEntryExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<AccountEntryExtWire, {
        v: 0;
    }>;
}
export declare class AccountEntryExtV1 extends AccountEntryExtBase {
    readonly type: "v1";
    readonly v1: AccountEntryExtensionV1;
    constructor(v1: AccountEntryExtensionV1);
    get value(): AccountEntryExtensionV1;
    toXdrObject(): Extract<AccountEntryExtWire, {
        v: 1;
    }>;
}
export type AccountEntryExt = AccountEntryExtV0 | AccountEntryExtV1;
export declare const AccountEntryExt: typeof AccountEntryExtBase;
export {};
