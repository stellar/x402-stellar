import { BytesValue } from "../values/bytes-value.js";
export type HashWire = Uint8Array;
/**
 * ```xdr
 * typedef opaque Hash[32];
 * ```
 */
export declare class Hash extends BytesValue<"Hash"> {
    static readonly byteLength = 32;
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): Hash;
}
