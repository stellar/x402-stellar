import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type ExtensionPointWire = {
    v: 0;
};
export type ExtensionPointVariantName = "v0";
/**
 * ```xdr
 * union ExtensionPoint switch (int v)
 * {
 * case 0:
 *     void;
 * };
 * ```
 */
declare abstract class ExtensionPointBase extends XdrValue {
    abstract readonly type: ExtensionPointVariantName;
    static readonly schema: XdrType<ExtensionPointWire>;
    static v0(): ExtensionPointV0;
    static fromXdrObject(wire: ExtensionPointWire): ExtensionPoint;
    abstract toXdrObject(): ExtensionPointWire;
}
export declare class ExtensionPointV0 extends ExtensionPointBase {
    readonly type: "v0";
    toXdrObject(): Extract<ExtensionPointWire, {
        v: 0;
    }>;
}
export type ExtensionPoint = ExtensionPointV0;
export declare const ExtensionPoint: typeof ExtensionPointBase;
export {};
