import { type XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { InflationPayout, type InflationPayoutWire } from "./inflation-payout.js";
export type InflationResultWire = {
    code: 0;
    payouts: InflationPayoutWire[];
} | {
    code: -1;
};
export type InflationResultVariantName = "inflationSuccess" | "inflationNotTime";
/**
 * ```xdr
 * union InflationResult switch (InflationResultCode code)
 * {
 * case INFLATION_SUCCESS:
 *     InflationPayout payouts<>;
 * case INFLATION_NOT_TIME:
 *     void;
 * };
 * ```
 */
declare abstract class InflationResultBase extends XdrValue {
    abstract readonly type: InflationResultVariantName;
    static readonly schema: XdrType<InflationResultWire>;
    static inflationSuccess(payouts: InflationPayout[]): InflationResultSuccess;
    static inflationNotTime(): InflationResultNotTime;
    static fromXdrObject(wire: InflationResultWire): InflationResult;
    abstract toXdrObject(): InflationResultWire;
}
export declare class InflationResultSuccess extends InflationResultBase {
    readonly type: "inflationSuccess";
    readonly payouts: InflationPayout[];
    constructor(payouts: InflationPayout[]);
    get value(): InflationPayout[];
    toXdrObject(): Extract<InflationResultWire, {
        code: 0;
    }>;
}
export declare class InflationResultNotTime extends InflationResultBase {
    readonly type: "inflationNotTime";
    toXdrObject(): Extract<InflationResultWire, {
        code: -1;
    }>;
}
export type InflationResult = InflationResultSuccess | InflationResultNotTime;
export declare const InflationResult: typeof InflationResultBase;
export {};
