import { EnumValue } from "../values/enum-value.js";
export type ClawbackResultCodeWire = number;
export type ClawbackResultCodeName = "clawbackSuccess" | "clawbackMalformed" | "clawbackNotClawbackEnabled" | "clawbackNoTrust" | "clawbackUnderfunded";
/**
 * ```xdr
 * enum ClawbackResultCode
 * {
 *     // codes considered as "success" for the operation
 *     CLAWBACK_SUCCESS = 0,
 *
 *     // codes considered as "failure" for the operation
 *     CLAWBACK_MALFORMED = -1,
 *     CLAWBACK_NOT_CLAWBACK_ENABLED = -2,
 *     CLAWBACK_NO_TRUST = -3,
 *     CLAWBACK_UNDERFUNDED = -4
 * };
 * ```
 */
export declare class ClawbackResultCode extends EnumValue<ClawbackResultCodeName> {
    static readonly clawbackSuccess: ClawbackResultCode;
    static readonly clawbackMalformed: ClawbackResultCode;
    static readonly clawbackNotClawbackEnabled: ClawbackResultCode;
    static readonly clawbackNoTrust: ClawbackResultCode;
    static readonly clawbackUnderfunded: ClawbackResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"ClawbackResultCode", {
        clawbackSuccess: number;
        clawbackMalformed: number;
        clawbackNotClawbackEnabled: number;
        clawbackNoTrust: number;
        clawbackUnderfunded: number;
    }>;
    static fromValue(value: number): ClawbackResultCode;
    static fromName(name: ClawbackResultCodeName): ClawbackResultCode;
    static fromXdrObject(wire: number): ClawbackResultCode;
}
