import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type LedgerEntryExtensionV1ExtWire = {
    v: 0;
};
export type LedgerEntryExtensionV1ExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class LedgerEntryExtensionV1ExtBase extends XdrValue {
    abstract readonly type: LedgerEntryExtensionV1ExtVariantName;
    static readonly schema: XdrType<LedgerEntryExtensionV1ExtWire>;
    static v0(): LedgerEntryExtensionV1ExtV0;
    static fromXdrObject(wire: LedgerEntryExtensionV1ExtWire): LedgerEntryExtensionV1Ext;
    abstract toXdrObject(): LedgerEntryExtensionV1ExtWire;
}
export declare class LedgerEntryExtensionV1ExtV0 extends LedgerEntryExtensionV1ExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<LedgerEntryExtensionV1ExtWire, {
        v: 0;
    }>;
}
export type LedgerEntryExtensionV1Ext = LedgerEntryExtensionV1ExtV0;
export declare const LedgerEntryExtensionV1Ext: typeof LedgerEntryExtensionV1ExtBase;
export {};
