import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type EndSponsoringFutureReservesResultWire = {
    code: 0;
} | {
    code: -1;
};
export type EndSponsoringFutureReservesResultVariantName = "endSponsoringFutureReservesSuccess" | "endSponsoringFutureReservesNotSponsored";
/**
 * ```xdr
 * union EndSponsoringFutureReservesResult switch (
 *     EndSponsoringFutureReservesResultCode code)
 * {
 * case END_SPONSORING_FUTURE_RESERVES_SUCCESS:
 *     void;
 * case END_SPONSORING_FUTURE_RESERVES_NOT_SPONSORED:
 *     void;
 * };
 * ```
 */
declare abstract class EndSponsoringFutureReservesResultBase extends XdrValue {
    abstract readonly type: EndSponsoringFutureReservesResultVariantName;
    static readonly schema: XdrType<EndSponsoringFutureReservesResultWire>;
    static endSponsoringFutureReservesSuccess(): EndSponsoringFutureReservesResultSuccess;
    static endSponsoringFutureReservesNotSponsored(): EndSponsoringFutureReservesResultNotSponsored;
    static fromXdrObject(wire: EndSponsoringFutureReservesResultWire): EndSponsoringFutureReservesResult;
    abstract toXdrObject(): EndSponsoringFutureReservesResultWire;
}
export declare class EndSponsoringFutureReservesResultSuccess extends EndSponsoringFutureReservesResultBase {
    readonly type: "endSponsoringFutureReservesSuccess";
    toXdrObject(): Extract<EndSponsoringFutureReservesResultWire, {
        code: 0;
    }>;
}
export declare class EndSponsoringFutureReservesResultNotSponsored extends EndSponsoringFutureReservesResultBase {
    readonly type: "endSponsoringFutureReservesNotSponsored";
    toXdrObject(): Extract<EndSponsoringFutureReservesResultWire, {
        code: -1;
    }>;
}
export type EndSponsoringFutureReservesResult = EndSponsoringFutureReservesResultSuccess | EndSponsoringFutureReservesResultNotSponsored;
export declare const EndSponsoringFutureReservesResult: typeof EndSponsoringFutureReservesResultBase;
export {};
