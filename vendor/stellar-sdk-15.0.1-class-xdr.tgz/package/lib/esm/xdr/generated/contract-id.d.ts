import { BytesValue } from "../values/bytes-value.js";
export type ContractIdWire = Uint8Array;
/**
 * ```xdr
 * typedef Hash ContractID;
 * ```
 */
export declare class ContractId extends BytesValue<"ContractId"> {
    static readonly byteLength = 32;
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): ContractId;
}
