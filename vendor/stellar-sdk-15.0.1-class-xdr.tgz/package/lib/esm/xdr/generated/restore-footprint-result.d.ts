import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type RestoreFootprintResultWire = {
    code: 0;
} | {
    code: -1;
} | {
    code: -2;
} | {
    code: -3;
};
export type RestoreFootprintResultVariantName = "restoreFootprintSuccess" | "restoreFootprintMalformed" | "restoreFootprintResourceLimitExceeded" | "restoreFootprintInsufficientRefundableFee";
/**
 * ```xdr
 * union RestoreFootprintResult switch (RestoreFootprintResultCode code)
 * {
 * case RESTORE_FOOTPRINT_SUCCESS:
 *     void;
 * case RESTORE_FOOTPRINT_MALFORMED:
 * case RESTORE_FOOTPRINT_RESOURCE_LIMIT_EXCEEDED:
 * case RESTORE_FOOTPRINT_INSUFFICIENT_REFUNDABLE_FEE:
 *     void;
 * };
 * ```
 */
declare abstract class RestoreFootprintResultBase extends XdrValue {
    abstract readonly type: RestoreFootprintResultVariantName;
    static readonly schema: XdrType<RestoreFootprintResultWire>;
    static restoreFootprintSuccess(): RestoreFootprintResultSuccess;
    static restoreFootprintMalformed(): RestoreFootprintResultMalformed;
    static restoreFootprintResourceLimitExceeded(): RestoreFootprintResultResourceLimitExceeded;
    static restoreFootprintInsufficientRefundableFee(): RestoreFootprintResultInsufficientRefundableFee;
    static fromXdrObject(wire: RestoreFootprintResultWire): RestoreFootprintResult;
    abstract toXdrObject(): RestoreFootprintResultWire;
}
export declare class RestoreFootprintResultSuccess extends RestoreFootprintResultBase {
    readonly type: "restoreFootprintSuccess";
    toXdrObject(): Extract<RestoreFootprintResultWire, {
        code: 0;
    }>;
}
export declare class RestoreFootprintResultMalformed extends RestoreFootprintResultBase {
    readonly type: "restoreFootprintMalformed";
    toXdrObject(): Extract<RestoreFootprintResultWire, {
        code: -1;
    }>;
}
export declare class RestoreFootprintResultResourceLimitExceeded extends RestoreFootprintResultBase {
    readonly type: "restoreFootprintResourceLimitExceeded";
    toXdrObject(): Extract<RestoreFootprintResultWire, {
        code: -2;
    }>;
}
export declare class RestoreFootprintResultInsufficientRefundableFee extends RestoreFootprintResultBase {
    readonly type: "restoreFootprintInsufficientRefundableFee";
    toXdrObject(): Extract<RestoreFootprintResultWire, {
        code: -3;
    }>;
}
export type RestoreFootprintResult = RestoreFootprintResultSuccess | RestoreFootprintResultMalformed | RestoreFootprintResultResourceLimitExceeded | RestoreFootprintResultInsufficientRefundableFee;
export declare const RestoreFootprintResult: typeof RestoreFootprintResultBase;
export {};
