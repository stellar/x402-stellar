import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type DataEntryExtWire = {
    v: 0;
};
export type DataEntryExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class DataEntryExtBase extends XdrValue {
    abstract readonly type: DataEntryExtVariantName;
    static readonly schema: XdrType<DataEntryExtWire>;
    static v0(): DataEntryExtV0;
    static fromXdrObject(wire: DataEntryExtWire): DataEntryExt;
    abstract toXdrObject(): DataEntryExtWire;
}
export declare class DataEntryExtV0 extends DataEntryExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<DataEntryExtWire, {
        v: 0;
    }>;
}
export type DataEntryExt = DataEntryExtV0;
export declare const DataEntryExt: typeof DataEntryExtBase;
export {};
