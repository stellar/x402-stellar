import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type OfferEntryExtWire = {
    v: 0;
};
export type OfferEntryExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class OfferEntryExtBase extends XdrValue {
    abstract readonly type: OfferEntryExtVariantName;
    static readonly schema: XdrType<OfferEntryExtWire>;
    static v0(): OfferEntryExtV0;
    static fromXdrObject(wire: OfferEntryExtWire): OfferEntryExt;
    abstract toXdrObject(): OfferEntryExtWire;
}
export declare class OfferEntryExtV0 extends OfferEntryExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<OfferEntryExtWire, {
        v: 0;
    }>;
}
export type OfferEntryExt = OfferEntryExtV0;
export declare const OfferEntryExt: typeof OfferEntryExtBase;
export {};
