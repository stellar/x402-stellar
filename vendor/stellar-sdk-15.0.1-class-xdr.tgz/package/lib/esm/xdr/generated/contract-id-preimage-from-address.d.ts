import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { ScAddress, type ScAddressWire } from "./sc-address.js";
export interface ContractIdPreimageFromAddressWire {
    address: ScAddressWire;
    salt: Uint8Array;
}
/**
 * ```xdr
 * struct
 *     {
 *         SCAddress address;
 *         uint256 salt;
 *     }
 * ```
 */
export declare class ContractIdPreimageFromAddress extends XdrValue {
    readonly address: ScAddress;
    readonly salt: Uint8Array;
    static readonly schema: XdrType<ContractIdPreimageFromAddressWire>;
    constructor(input: {
        address: ScAddress;
        salt: Uint8Array;
    });
    toXdrObject(): ContractIdPreimageFromAddressWire;
    static fromXdrObject(wire: ContractIdPreimageFromAddressWire): ContractIdPreimageFromAddress;
}
