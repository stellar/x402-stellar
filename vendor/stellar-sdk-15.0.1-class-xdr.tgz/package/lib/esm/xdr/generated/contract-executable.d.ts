import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { Hash, type HashWire } from "./hash.js";
export type ContractExecutableWire = {
    type: 0;
    wasmHash: HashWire;
} | {
    type: 1;
};
export type ContractExecutableVariantName = "contractExecutableWasm" | "contractExecutableStellarAsset";
/**
 * ```xdr
 * union ContractExecutable switch (ContractExecutableType type)
 * {
 * case CONTRACT_EXECUTABLE_WASM:
 *     Hash wasm_hash;
 * case CONTRACT_EXECUTABLE_STELLAR_ASSET:
 *     void;
 * };
 * ```
 */
declare abstract class ContractExecutableBase extends XdrValue {
    abstract readonly type: ContractExecutableVariantName;
    static readonly schema: XdrType<ContractExecutableWire>;
    static contractExecutableWasm(wasmHash: Hash | Uint8Array | string): ContractExecutableWasm;
    static contractExecutableStellarAsset(): ContractExecutableStellarAsset;
    static fromXdrObject(wire: ContractExecutableWire): ContractExecutable;
    abstract toXdrObject(): ContractExecutableWire;
}
export declare class ContractExecutableWasm extends ContractExecutableBase {
    readonly type: "contractExecutableWasm";
    readonly wasmHash: Hash;
    constructor(wasmHash: Hash | Uint8Array | string);
    get value(): Hash;
    toXdrObject(): Extract<ContractExecutableWire, {
        type: 0;
    }>;
}
export declare class ContractExecutableStellarAsset extends ContractExecutableBase {
    readonly type: "contractExecutableStellarAsset";
    toXdrObject(): Extract<ContractExecutableWire, {
        type: 1;
    }>;
}
export type ContractExecutable = ContractExecutableWasm | ContractExecutableStellarAsset;
export declare const ContractExecutable: typeof ContractExecutableBase;
export {};
