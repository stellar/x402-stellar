import { EnumValue } from "../values/enum-value.js";
export type ManageSellOfferResultCodeWire = number;
export type ManageSellOfferResultCodeName = "manageSellOfferSuccess" | "manageSellOfferMalformed" | "manageSellOfferSellNoTrust" | "manageSellOfferBuyNoTrust" | "manageSellOfferSellNotAuthorized" | "manageSellOfferBuyNotAuthorized" | "manageSellOfferLineFull" | "manageSellOfferUnderfunded" | "manageSellOfferCrossSelf" | "manageSellOfferSellNoIssuer" | "manageSellOfferBuyNoIssuer" | "manageSellOfferNotFound" | "manageSellOfferLowReserve";
/**
 * ```xdr
 * enum ManageSellOfferResultCode
 * {
 *     // codes considered as "success" for the operation
 *     MANAGE_SELL_OFFER_SUCCESS = 0,
 *
 *     // codes considered as "failure" for the operation
 *     MANAGE_SELL_OFFER_MALFORMED = -1, // generated offer would be invalid
 *     MANAGE_SELL_OFFER_SELL_NO_TRUST =
 *         -2,                              // no trust line for what we're selling
 *     MANAGE_SELL_OFFER_BUY_NO_TRUST = -3, // no trust line for what we're buying
 *     MANAGE_SELL_OFFER_SELL_NOT_AUTHORIZED = -4, // not authorized to sell
 *     MANAGE_SELL_OFFER_BUY_NOT_AUTHORIZED = -5,  // not authorized to buy
 *     MANAGE_SELL_OFFER_LINE_FULL = -6, // can't receive more of what it's buying
 *     MANAGE_SELL_OFFER_UNDERFUNDED = -7, // doesn't hold what it's trying to sell
 *     MANAGE_SELL_OFFER_CROSS_SELF =
 *         -8, // would cross an offer from the same user
 *     MANAGE_SELL_OFFER_SELL_NO_ISSUER = -9, // no issuer for what we're selling
 *     MANAGE_SELL_OFFER_BUY_NO_ISSUER = -10, // no issuer for what we're buying
 *
 *     // update errors
 *     MANAGE_SELL_OFFER_NOT_FOUND =
 *         -11, // offerID does not match an existing offer
 *
 *     MANAGE_SELL_OFFER_LOW_RESERVE =
 *         -12 // not enough funds to create a new Offer
 * };
 * ```
 */
export declare class ManageSellOfferResultCode extends EnumValue<ManageSellOfferResultCodeName> {
    static readonly manageSellOfferSuccess: ManageSellOfferResultCode;
    static readonly manageSellOfferMalformed: ManageSellOfferResultCode;
    static readonly manageSellOfferSellNoTrust: ManageSellOfferResultCode;
    static readonly manageSellOfferBuyNoTrust: ManageSellOfferResultCode;
    static readonly manageSellOfferSellNotAuthorized: ManageSellOfferResultCode;
    static readonly manageSellOfferBuyNotAuthorized: ManageSellOfferResultCode;
    static readonly manageSellOfferLineFull: ManageSellOfferResultCode;
    static readonly manageSellOfferUnderfunded: ManageSellOfferResultCode;
    static readonly manageSellOfferCrossSelf: ManageSellOfferResultCode;
    static readonly manageSellOfferSellNoIssuer: ManageSellOfferResultCode;
    static readonly manageSellOfferBuyNoIssuer: ManageSellOfferResultCode;
    static readonly manageSellOfferNotFound: ManageSellOfferResultCode;
    static readonly manageSellOfferLowReserve: ManageSellOfferResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"ManageSellOfferResultCode", {
        manageSellOfferSuccess: number;
        manageSellOfferMalformed: number;
        manageSellOfferSellNoTrust: number;
        manageSellOfferBuyNoTrust: number;
        manageSellOfferSellNotAuthorized: number;
        manageSellOfferBuyNotAuthorized: number;
        manageSellOfferLineFull: number;
        manageSellOfferUnderfunded: number;
        manageSellOfferCrossSelf: number;
        manageSellOfferSellNoIssuer: number;
        manageSellOfferBuyNoIssuer: number;
        manageSellOfferNotFound: number;
        manageSellOfferLowReserve: number;
    }>;
    static fromValue(value: number): ManageSellOfferResultCode;
    static fromName(name: ManageSellOfferResultCodeName): ManageSellOfferResultCode;
    static fromXdrObject(wire: number): ManageSellOfferResultCode;
}
