import { EnumValue } from "../values/enum-value.js";
export type ExtendFootprintTtlResultCodeWire = number;
export type ExtendFootprintTtlResultCodeName = "extendFootprintTtlSuccess" | "extendFootprintTtlMalformed" | "extendFootprintTtlResourceLimitExceeded" | "extendFootprintTtlInsufficientRefundableFee";
/**
 * ```xdr
 * enum ExtendFootprintTTLResultCode
 * {
 *     // codes considered as "success" for the operation
 *     EXTEND_FOOTPRINT_TTL_SUCCESS = 0,
 *
 *     // codes considered as "failure" for the operation
 *     EXTEND_FOOTPRINT_TTL_MALFORMED = -1,
 *     EXTEND_FOOTPRINT_TTL_RESOURCE_LIMIT_EXCEEDED = -2,
 *     EXTEND_FOOTPRINT_TTL_INSUFFICIENT_REFUNDABLE_FEE = -3
 * };
 * ```
 */
export declare class ExtendFootprintTtlResultCode extends EnumValue<ExtendFootprintTtlResultCodeName> {
    static readonly extendFootprintTtlSuccess: ExtendFootprintTtlResultCode;
    static readonly extendFootprintTtlMalformed: ExtendFootprintTtlResultCode;
    static readonly extendFootprintTtlResourceLimitExceeded: ExtendFootprintTtlResultCode;
    static readonly extendFootprintTtlInsufficientRefundableFee: ExtendFootprintTtlResultCode;
    static readonly schema: import("../types/enum.js").EnumSchema<"ExtendFootprintTtlResultCode", {
        extendFootprintTtlSuccess: number;
        extendFootprintTtlMalformed: number;
        extendFootprintTtlResourceLimitExceeded: number;
        extendFootprintTtlInsufficientRefundableFee: number;
    }>;
    static fromValue(value: number): ExtendFootprintTtlResultCode;
    static fromName(name: ExtendFootprintTtlResultCodeName): ExtendFootprintTtlResultCode;
    static fromXdrObject(wire: number): ExtendFootprintTtlResultCode;
}
