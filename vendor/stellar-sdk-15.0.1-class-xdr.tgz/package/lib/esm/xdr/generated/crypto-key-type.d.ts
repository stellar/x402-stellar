import { EnumValue } from "../values/enum-value.js";
export type CryptoKeyTypeWire = number;
export type CryptoKeyTypeName = "keyTypeEd25519" | "keyTypePreAuthTx" | "keyTypeHashX" | "keyTypeEd25519SignedPayload" | "keyTypeMuxedEd25519";
/**
 * ```xdr
 * enum CryptoKeyType
 * {
 *     KEY_TYPE_ED25519 = 0,
 *     KEY_TYPE_PRE_AUTH_TX = 1,
 *     KEY_TYPE_HASH_X = 2,
 *     KEY_TYPE_ED25519_SIGNED_PAYLOAD = 3,
 *     // MUXED enum values for supported type are derived from the enum values
 *     // above by ORing them with 0x100
 *     KEY_TYPE_MUXED_ED25519 = 0x100
 * };
 * ```
 */
export declare class CryptoKeyType extends EnumValue<CryptoKeyTypeName> {
    static readonly keyTypeEd25519: CryptoKeyType;
    static readonly keyTypePreAuthTx: CryptoKeyType;
    static readonly keyTypeHashX: CryptoKeyType;
    static readonly keyTypeEd25519SignedPayload: CryptoKeyType;
    static readonly keyTypeMuxedEd25519: CryptoKeyType;
    static readonly schema: import("../types/enum.js").EnumSchema<"CryptoKeyType", {
        keyTypeEd25519: number;
        keyTypePreAuthTx: number;
        keyTypeHashX: number;
        keyTypeEd25519SignedPayload: number;
        keyTypeMuxedEd25519: number;
    }>;
    static fromValue(value: number): CryptoKeyType;
    static fromName(name: CryptoKeyTypeName): CryptoKeyType;
    static fromXdrObject(wire: number): CryptoKeyType;
}
