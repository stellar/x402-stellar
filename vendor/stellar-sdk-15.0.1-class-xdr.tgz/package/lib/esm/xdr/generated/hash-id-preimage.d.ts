import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { HashIdPreimageOperationId, type HashIdPreimageOperationIdWire } from "./hash-id-preimage-operation-id.js";
import { HashIdPreimageRevokeId, type HashIdPreimageRevokeIdWire } from "./hash-id-preimage-revoke-id.js";
import { HashIdPreimageContractId, type HashIdPreimageContractIdWire } from "./hash-id-preimage-contract-id.js";
import { HashIdPreimageSorobanAuthorization, type HashIdPreimageSorobanAuthorizationWire } from "./hash-id-preimage-soroban-authorization.js";
export type HashIdPreimageWire = {
    type: 6;
    operationId: HashIdPreimageOperationIdWire;
} | {
    type: 7;
    revokeId: HashIdPreimageRevokeIdWire;
} | {
    type: 8;
    contractId: HashIdPreimageContractIdWire;
} | {
    type: 9;
    sorobanAuthorization: HashIdPreimageSorobanAuthorizationWire;
};
export type HashIdPreimageVariantName = "envelopeTypeOpId" | "envelopeTypePoolRevokeOpId" | "envelopeTypeContractId" | "envelopeTypeSorobanAuthorization";
/**
 * ```xdr
 * union HashIDPreimage switch (EnvelopeType type)
 * {
 * case ENVELOPE_TYPE_OP_ID:
 *     struct
 *     {
 *         AccountID sourceAccount;
 *         SequenceNumber seqNum;
 *         uint32 opNum;
 *     } operationID;
 * case ENVELOPE_TYPE_POOL_REVOKE_OP_ID:
 *     struct
 *     {
 *         AccountID sourceAccount;
 *         SequenceNumber seqNum;
 *         uint32 opNum;
 *         PoolID liquidityPoolID;
 *         Asset asset;
 *     } revokeID;
 * case ENVELOPE_TYPE_CONTRACT_ID:
 *     struct
 *     {
 *         Hash networkID;
 *         ContractIDPreimage contractIDPreimage;
 *     } contractID;
 * case ENVELOPE_TYPE_SOROBAN_AUTHORIZATION:
 *     struct
 *     {
 *         Hash networkID;
 *         int64 nonce;
 *         uint32 signatureExpirationLedger;
 *         SorobanAuthorizedInvocation invocation;
 *     } sorobanAuthorization;
 * #ifdef CAP_0071
 * case ENVELOPE_TYPE_SOROBAN_AUTHORIZATION_WITH_ADDRESS:
 *     struct
 *     {
 *         Hash networkID;
 *         int64 nonce;
 *         uint32 signatureExpirationLedger;
 *         SCAddress address;
 *         SorobanAuthorizedInvocation invocation;
 *     } sorobanAuthorizationWithAddress;
 * #endif
 * };
 * ```
 */
declare abstract class HashIdPreimageBase extends XdrValue {
    abstract readonly type: HashIdPreimageVariantName;
    static readonly schema: XdrType<HashIdPreimageWire>;
    static envelopeTypeOpId(operationId: HashIdPreimageOperationId): HashIdPreimageOpId;
    static envelopeTypePoolRevokeOpId(revokeId: HashIdPreimageRevokeId): HashIdPreimagePoolRevokeOpId;
    static envelopeTypeContractId(contractId: HashIdPreimageContractId): HashIdPreimageContractIdArm;
    static envelopeTypeSorobanAuthorization(sorobanAuthorization: HashIdPreimageSorobanAuthorization): HashIdPreimageSorobanAuthorizationArm;
    static fromXdrObject(wire: HashIdPreimageWire): HashIdPreimage;
    abstract toXdrObject(): HashIdPreimageWire;
}
export declare class HashIdPreimageOpId extends HashIdPreimageBase {
    readonly type: "envelopeTypeOpId";
    readonly operationId: HashIdPreimageOperationId;
    constructor(operationId: HashIdPreimageOperationId);
    get value(): HashIdPreimageOperationId;
    toXdrObject(): Extract<HashIdPreimageWire, {
        type: 6;
    }>;
}
export declare class HashIdPreimagePoolRevokeOpId extends HashIdPreimageBase {
    readonly type: "envelopeTypePoolRevokeOpId";
    readonly revokeId: HashIdPreimageRevokeId;
    constructor(revokeId: HashIdPreimageRevokeId);
    get value(): HashIdPreimageRevokeId;
    toXdrObject(): Extract<HashIdPreimageWire, {
        type: 7;
    }>;
}
export declare class HashIdPreimageContractIdArm extends HashIdPreimageBase {
    readonly type: "envelopeTypeContractId";
    readonly contractId: HashIdPreimageContractId;
    constructor(contractId: HashIdPreimageContractId);
    get value(): HashIdPreimageContractId;
    toXdrObject(): Extract<HashIdPreimageWire, {
        type: 8;
    }>;
}
export declare class HashIdPreimageSorobanAuthorizationArm extends HashIdPreimageBase {
    readonly type: "envelopeTypeSorobanAuthorization";
    readonly sorobanAuthorization: HashIdPreimageSorobanAuthorization;
    constructor(sorobanAuthorization: HashIdPreimageSorobanAuthorization);
    get value(): HashIdPreimageSorobanAuthorization;
    toXdrObject(): Extract<HashIdPreimageWire, {
        type: 9;
    }>;
}
export type HashIdPreimage = HashIdPreimageOpId | HashIdPreimagePoolRevokeOpId | HashIdPreimageContractIdArm | HashIdPreimageSorobanAuthorizationArm;
export declare const HashIdPreimage: typeof HashIdPreimageBase;
export {};
