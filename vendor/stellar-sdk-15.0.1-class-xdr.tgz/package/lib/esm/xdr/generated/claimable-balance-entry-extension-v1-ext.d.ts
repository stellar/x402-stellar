import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type ClaimableBalanceEntryExtensionV1ExtWire = {
    v: 0;
};
export type ClaimableBalanceEntryExtensionV1ExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class ClaimableBalanceEntryExtensionV1ExtBase extends XdrValue {
    abstract readonly type: ClaimableBalanceEntryExtensionV1ExtVariantName;
    static readonly schema: XdrType<ClaimableBalanceEntryExtensionV1ExtWire>;
    static v0(): ClaimableBalanceEntryExtensionV1ExtV0;
    static fromXdrObject(wire: ClaimableBalanceEntryExtensionV1ExtWire): ClaimableBalanceEntryExtensionV1Ext;
    abstract toXdrObject(): ClaimableBalanceEntryExtensionV1ExtWire;
}
export declare class ClaimableBalanceEntryExtensionV1ExtV0 extends ClaimableBalanceEntryExtensionV1ExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<ClaimableBalanceEntryExtensionV1ExtWire, {
        v: 0;
    }>;
}
export type ClaimableBalanceEntryExtensionV1Ext = ClaimableBalanceEntryExtensionV1ExtV0;
export declare const ClaimableBalanceEntryExtensionV1Ext: typeof ClaimableBalanceEntryExtensionV1ExtBase;
export {};
