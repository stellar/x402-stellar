import { BytesValue } from "../values/bytes-value.js";
export type ScBytesWire = Uint8Array;
/**
 * ```xdr
 * typedef opaque SCBytes<>;
 * ```
 */
export declare class ScBytes extends BytesValue<"ScBytes"> {
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): ScBytes;
}
