import { EnumValue } from "../values/enum-value.js";
export type HotArchiveBucketEntryTypeWire = number;
export type HotArchiveBucketEntryTypeName = "hotArchiveMetaentry" | "hotArchiveArchived" | "hotArchiveLive";
/**
 * ```xdr
 * enum HotArchiveBucketEntryType
 * {
 *     HOT_ARCHIVE_METAENTRY = -1, // Bucket metadata, should come first.
 *     HOT_ARCHIVE_ARCHIVED = 0,   // Entry is Archived
 *     HOT_ARCHIVE_LIVE = 1        // Entry was previously HOT_ARCHIVE_ARCHIVED, but
 *                                 // has been added back to the live BucketList.
 *                                 // Does not need to be persisted.
 * };
 * ```
 */
export declare class HotArchiveBucketEntryType extends EnumValue<HotArchiveBucketEntryTypeName> {
    static readonly hotArchiveMetaentry: HotArchiveBucketEntryType;
    static readonly hotArchiveArchived: HotArchiveBucketEntryType;
    static readonly hotArchiveLive: HotArchiveBucketEntryType;
    static readonly schema: import("../types/enum.js").EnumSchema<"HotArchiveBucketEntryType", {
        hotArchiveMetaentry: number;
        hotArchiveArchived: number;
        hotArchiveLive: number;
    }>;
    static fromValue(value: number): HotArchiveBucketEntryType;
    static fromName(name: HotArchiveBucketEntryTypeName): HotArchiveBucketEntryType;
    static fromXdrObject(wire: number): HotArchiveBucketEntryType;
}
