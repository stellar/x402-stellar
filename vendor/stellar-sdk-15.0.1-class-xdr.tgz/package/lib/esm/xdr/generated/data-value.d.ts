import { BytesValue } from "../values/bytes-value.js";
export type DataValueWire = Uint8Array;
/**
 * ```xdr
 * typedef opaque DataValue<64>;
 * ```
 */
export declare class DataValue extends BytesValue<"DataValue"> {
    static readonly encoding: "hex";
    static readonly schema: import("../core/xdr-type.js").XdrType<Uint8Array<ArrayBufferLike>>;
    static fromXdrObject(wire: Uint8Array): DataValue;
}
