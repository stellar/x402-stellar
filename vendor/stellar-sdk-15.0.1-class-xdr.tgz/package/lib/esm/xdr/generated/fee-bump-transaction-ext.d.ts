import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type FeeBumpTransactionExtWire = {
    v: 0;
};
export type FeeBumpTransactionExtVariantName = "v0";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     }
 * ```
 */
declare abstract class FeeBumpTransactionExtBase extends XdrValue {
    abstract readonly type: FeeBumpTransactionExtVariantName;
    static readonly schema: XdrType<FeeBumpTransactionExtWire>;
    static v0(): FeeBumpTransactionExtV0;
    static fromXdrObject(wire: FeeBumpTransactionExtWire): FeeBumpTransactionExt;
    abstract toXdrObject(): FeeBumpTransactionExtWire;
}
export declare class FeeBumpTransactionExtV0 extends FeeBumpTransactionExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<FeeBumpTransactionExtWire, {
        v: 0;
    }>;
}
export type FeeBumpTransactionExt = FeeBumpTransactionExtV0;
export declare const FeeBumpTransactionExt: typeof FeeBumpTransactionExtBase;
export {};
