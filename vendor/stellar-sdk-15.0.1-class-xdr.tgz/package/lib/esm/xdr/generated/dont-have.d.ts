import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { MessageType, type MessageTypeWire } from "./message-type.js";
export interface DontHaveWire {
    type: MessageTypeWire;
    reqHash: Uint8Array;
}
/**
 * ```xdr
 * struct DontHave
 * {
 *     MessageType type;
 *     uint256 reqHash;
 * };
 * ```
 */
export declare class DontHave extends XdrValue {
    readonly type: MessageType;
    readonly reqHash: Uint8Array;
    static readonly schema: XdrType<DontHaveWire>;
    constructor(input: {
        type: MessageType;
        reqHash: Uint8Array;
    });
    toXdrObject(): DontHaveWire;
    static fromXdrObject(wire: DontHaveWire): DontHave;
}
