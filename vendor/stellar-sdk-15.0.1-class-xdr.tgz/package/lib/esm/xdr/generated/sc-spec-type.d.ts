import { EnumValue } from "../values/enum-value.js";
export type ScSpecTypeWire = number;
export type ScSpecTypeName = "scSpecTypeVal" | "scSpecTypeBool" | "scSpecTypeVoid" | "scSpecTypeError" | "scSpecTypeU32" | "scSpecTypeI32" | "scSpecTypeU64" | "scSpecTypeI64" | "scSpecTypeTimepoint" | "scSpecTypeDuration" | "scSpecTypeU128" | "scSpecTypeI128" | "scSpecTypeU256" | "scSpecTypeI256" | "scSpecTypeBytes" | "scSpecTypeString" | "scSpecTypeSymbol" | "scSpecTypeAddress" | "scSpecTypeMuxedAddress" | "scSpecTypeOption" | "scSpecTypeResult" | "scSpecTypeVec" | "scSpecTypeMap" | "scSpecTypeTuple" | "scSpecTypeBytesN" | "scSpecTypeUdt";
/**
 * ```xdr
 * enum SCSpecType
 * {
 *     SC_SPEC_TYPE_VAL = 0,
 *
 *     // Types with no parameters.
 *     SC_SPEC_TYPE_BOOL = 1,
 *     SC_SPEC_TYPE_VOID = 2,
 *     SC_SPEC_TYPE_ERROR = 3,
 *     SC_SPEC_TYPE_U32 = 4,
 *     SC_SPEC_TYPE_I32 = 5,
 *     SC_SPEC_TYPE_U64 = 6,
 *     SC_SPEC_TYPE_I64 = 7,
 *     SC_SPEC_TYPE_TIMEPOINT = 8,
 *     SC_SPEC_TYPE_DURATION = 9,
 *     SC_SPEC_TYPE_U128 = 10,
 *     SC_SPEC_TYPE_I128 = 11,
 *     SC_SPEC_TYPE_U256 = 12,
 *     SC_SPEC_TYPE_I256 = 13,
 *     SC_SPEC_TYPE_BYTES = 14,
 *     SC_SPEC_TYPE_STRING = 16,
 *     SC_SPEC_TYPE_SYMBOL = 17,
 *     SC_SPEC_TYPE_ADDRESS = 19,
 *     SC_SPEC_TYPE_MUXED_ADDRESS = 20,
 *
 *     // Types with parameters.
 *     SC_SPEC_TYPE_OPTION = 1000,
 *     SC_SPEC_TYPE_RESULT = 1001,
 *     SC_SPEC_TYPE_VEC = 1002,
 *     SC_SPEC_TYPE_MAP = 1004,
 *     SC_SPEC_TYPE_TUPLE = 1005,
 *     SC_SPEC_TYPE_BYTES_N = 1006,
 *
 *     // User defined types.
 *     SC_SPEC_TYPE_UDT = 2000
 * };
 * ```
 */
export declare class ScSpecType extends EnumValue<ScSpecTypeName> {
    static readonly scSpecTypeVal: ScSpecType;
    static readonly scSpecTypeBool: ScSpecType;
    static readonly scSpecTypeVoid: ScSpecType;
    static readonly scSpecTypeError: ScSpecType;
    static readonly scSpecTypeU32: ScSpecType;
    static readonly scSpecTypeI32: ScSpecType;
    static readonly scSpecTypeU64: ScSpecType;
    static readonly scSpecTypeI64: ScSpecType;
    static readonly scSpecTypeTimepoint: ScSpecType;
    static readonly scSpecTypeDuration: ScSpecType;
    static readonly scSpecTypeU128: ScSpecType;
    static readonly scSpecTypeI128: ScSpecType;
    static readonly scSpecTypeU256: ScSpecType;
    static readonly scSpecTypeI256: ScSpecType;
    static readonly scSpecTypeBytes: ScSpecType;
    static readonly scSpecTypeString: ScSpecType;
    static readonly scSpecTypeSymbol: ScSpecType;
    static readonly scSpecTypeAddress: ScSpecType;
    static readonly scSpecTypeMuxedAddress: ScSpecType;
    static readonly scSpecTypeOption: ScSpecType;
    static readonly scSpecTypeResult: ScSpecType;
    static readonly scSpecTypeVec: ScSpecType;
    static readonly scSpecTypeMap: ScSpecType;
    static readonly scSpecTypeTuple: ScSpecType;
    static readonly scSpecTypeBytesN: ScSpecType;
    static readonly scSpecTypeUdt: ScSpecType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ScSpecType", {
        scSpecTypeVal: number;
        scSpecTypeBool: number;
        scSpecTypeVoid: number;
        scSpecTypeError: number;
        scSpecTypeU32: number;
        scSpecTypeI32: number;
        scSpecTypeU64: number;
        scSpecTypeI64: number;
        scSpecTypeTimepoint: number;
        scSpecTypeDuration: number;
        scSpecTypeU128: number;
        scSpecTypeI128: number;
        scSpecTypeU256: number;
        scSpecTypeI256: number;
        scSpecTypeBytes: number;
        scSpecTypeString: number;
        scSpecTypeSymbol: number;
        scSpecTypeAddress: number;
        scSpecTypeMuxedAddress: number;
        scSpecTypeOption: number;
        scSpecTypeResult: number;
        scSpecTypeVec: number;
        scSpecTypeMap: number;
        scSpecTypeTuple: number;
        scSpecTypeBytesN: number;
        scSpecTypeUdt: number;
    }>;
    static fromValue(value: number): ScSpecType;
    static fromName(name: ScSpecTypeName): ScSpecType;
    static fromXdrObject(wire: number): ScSpecType;
}
