import { EnumValue } from "../values/enum-value.js";
export type BucketEntryTypeWire = number;
export type BucketEntryTypeName = "metaentry" | "liveentry" | "deadentry" | "initentry";
/**
 * ```xdr
 * enum BucketEntryType
 * {
 *     METAENTRY =
 *         -1, // At-and-after protocol 11: bucket metadata, should come first.
 *     LIVEENTRY = 0, // Before protocol 11: created-or-updated;
 *                    // At-and-after protocol 11: only updated.
 *     DEADENTRY = 1,
 *     INITENTRY = 2 // At-and-after protocol 11: only created.
 * };
 * ```
 */
export declare class BucketEntryType extends EnumValue<BucketEntryTypeName> {
    static readonly metaentry: BucketEntryType;
    static readonly liveentry: BucketEntryType;
    static readonly deadentry: BucketEntryType;
    static readonly initentry: BucketEntryType;
    static readonly schema: import("../types/enum.js").EnumSchema<"BucketEntryType", {
        metaentry: number;
        liveentry: number;
        deadentry: number;
        initentry: number;
    }>;
    static fromValue(value: number): BucketEntryType;
    static fromName(name: BucketEntryTypeName): BucketEntryType;
    static fromXdrObject(wire: number): BucketEntryType;
}
