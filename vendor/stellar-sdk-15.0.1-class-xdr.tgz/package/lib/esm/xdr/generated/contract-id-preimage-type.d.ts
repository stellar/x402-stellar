import { EnumValue } from "../values/enum-value.js";
export type ContractIdPreimageTypeWire = number;
export type ContractIdPreimageTypeName = "contractIdPreimageFromAddress" | "contractIdPreimageFromAsset";
/**
 * ```xdr
 * enum ContractIDPreimageType
 * {
 *     CONTRACT_ID_PREIMAGE_FROM_ADDRESS = 0,
 *     CONTRACT_ID_PREIMAGE_FROM_ASSET = 1
 * };
 * ```
 */
export declare class ContractIdPreimageType extends EnumValue<ContractIdPreimageTypeName> {
    static readonly contractIdPreimageFromAddress: ContractIdPreimageType;
    static readonly contractIdPreimageFromAsset: ContractIdPreimageType;
    static readonly schema: import("../types/enum.js").EnumSchema<"ContractIdPreimageType", {
        contractIdPreimageFromAddress: number;
        contractIdPreimageFromAsset: number;
    }>;
    static fromValue(value: number): ContractIdPreimageType;
    static fromName(name: ContractIdPreimageTypeName): ContractIdPreimageType;
    static fromXdrObject(wire: number): ContractIdPreimageType;
}
