import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
import { BucketListType, type BucketListTypeWire } from "./bucket-list-type.js";
export type BucketMetadataExtWire = {
    v: 0;
} | {
    v: 1;
    bucketListType: BucketListTypeWire;
};
export type BucketMetadataExtVariantName = "v0" | "bucketListType";
/**
 * ```xdr
 * union switch (int v)
 *     {
 *     case 0:
 *         void;
 *     case 1:
 *         BucketListType bucketListType;
 *     }
 * ```
 */
declare abstract class BucketMetadataExtBase extends XdrValue {
    abstract readonly type: BucketMetadataExtVariantName;
    static readonly schema: XdrType<BucketMetadataExtWire>;
    static v0(): BucketMetadataExtV0;
    static bucketListType(bucketListType: BucketListType): BucketMetadataExtBucketListtype;
    static fromXdrObject(wire: BucketMetadataExtWire): BucketMetadataExt;
    abstract toXdrObject(): BucketMetadataExtWire;
}
export declare class BucketMetadataExtV0 extends BucketMetadataExtBase {
    readonly type: "v0";
    toXdrObject(): Extract<BucketMetadataExtWire, {
        v: 0;
    }>;
}
export declare class BucketMetadataExtBucketListtype extends BucketMetadataExtBase {
    readonly type: "bucketListType";
    readonly bucketListType: BucketListType;
    constructor(bucketListType: BucketListType);
    get value(): BucketListType;
    toXdrObject(): Extract<BucketMetadataExtWire, {
        v: 1;
    }>;
}
export type BucketMetadataExt = BucketMetadataExtV0 | BucketMetadataExtBucketListtype;
export declare const BucketMetadataExt: typeof BucketMetadataExtBase;
export {};
