import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type SetTrustLineFlagsResultWire = {
    code: 0;
} | {
    code: -1;
} | {
    code: -2;
} | {
    code: -3;
} | {
    code: -4;
} | {
    code: -5;
};
export type SetTrustLineFlagsResultVariantName = "setTrustLineFlagsSuccess" | "setTrustLineFlagsMalformed" | "setTrustLineFlagsNoTrustLine" | "setTrustLineFlagsCantRevoke" | "setTrustLineFlagsInvalidState" | "setTrustLineFlagsLowReserve";
/**
 * ```xdr
 * union SetTrustLineFlagsResult switch (SetTrustLineFlagsResultCode code)
 * {
 * case SET_TRUST_LINE_FLAGS_SUCCESS:
 *     void;
 * case SET_TRUST_LINE_FLAGS_MALFORMED:
 * case SET_TRUST_LINE_FLAGS_NO_TRUST_LINE:
 * case SET_TRUST_LINE_FLAGS_CANT_REVOKE:
 * case SET_TRUST_LINE_FLAGS_INVALID_STATE:
 * case SET_TRUST_LINE_FLAGS_LOW_RESERVE:
 *     void;
 * };
 * ```
 */
declare abstract class SetTrustLineFlagsResultBase extends XdrValue {
    abstract readonly type: SetTrustLineFlagsResultVariantName;
    static readonly schema: XdrType<SetTrustLineFlagsResultWire>;
    static setTrustLineFlagsSuccess(): SetTrustLineFlagsResultSuccess;
    static setTrustLineFlagsMalformed(): SetTrustLineFlagsResultMalformed;
    static setTrustLineFlagsNoTrustLine(): SetTrustLineFlagsResultNoTrustLine;
    static setTrustLineFlagsCantRevoke(): SetTrustLineFlagsResultCantRevoke;
    static setTrustLineFlagsInvalidState(): SetTrustLineFlagsResultInvalidState;
    static setTrustLineFlagsLowReserve(): SetTrustLineFlagsResultLowReserve;
    static fromXdrObject(wire: SetTrustLineFlagsResultWire): SetTrustLineFlagsResult;
    abstract toXdrObject(): SetTrustLineFlagsResultWire;
}
export declare class SetTrustLineFlagsResultSuccess extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsSuccess";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: 0;
    }>;
}
export declare class SetTrustLineFlagsResultMalformed extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsMalformed";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: -1;
    }>;
}
export declare class SetTrustLineFlagsResultNoTrustLine extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsNoTrustLine";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: -2;
    }>;
}
export declare class SetTrustLineFlagsResultCantRevoke extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsCantRevoke";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: -3;
    }>;
}
export declare class SetTrustLineFlagsResultInvalidState extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsInvalidState";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: -4;
    }>;
}
export declare class SetTrustLineFlagsResultLowReserve extends SetTrustLineFlagsResultBase {
    readonly type: "setTrustLineFlagsLowReserve";
    toXdrObject(): Extract<SetTrustLineFlagsResultWire, {
        code: -5;
    }>;
}
export type SetTrustLineFlagsResult = SetTrustLineFlagsResultSuccess | SetTrustLineFlagsResultMalformed | SetTrustLineFlagsResultNoTrustLine | SetTrustLineFlagsResultCantRevoke | SetTrustLineFlagsResultInvalidState | SetTrustLineFlagsResultLowReserve;
export declare const SetTrustLineFlagsResult: typeof SetTrustLineFlagsResultBase;
export {};
