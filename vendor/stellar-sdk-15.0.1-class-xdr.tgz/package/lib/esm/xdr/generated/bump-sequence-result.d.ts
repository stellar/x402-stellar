import type { XdrType } from "../core/xdr-type.js";
import { XdrValue } from "../values/xdr-value.js";
export type BumpSequenceResultWire = {
    code: 0;
} | {
    code: -1;
};
export type BumpSequenceResultVariantName = "bumpSequenceSuccess" | "bumpSequenceBadSeq";
/**
 * ```xdr
 * union BumpSequenceResult switch (BumpSequenceResultCode code)
 * {
 * case BUMP_SEQUENCE_SUCCESS:
 *     void;
 * case BUMP_SEQUENCE_BAD_SEQ:
 *     void;
 * };
 * ```
 */
declare abstract class BumpSequenceResultBase extends XdrValue {
    abstract readonly type: BumpSequenceResultVariantName;
    static readonly schema: XdrType<BumpSequenceResultWire>;
    static bumpSequenceSuccess(): BumpSequenceResultSuccess;
    static bumpSequenceBadSeq(): BumpSequenceResultBadSeq;
    static fromXdrObject(wire: BumpSequenceResultWire): BumpSequenceResult;
    abstract toXdrObject(): BumpSequenceResultWire;
}
export declare class BumpSequenceResultSuccess extends BumpSequenceResultBase {
    readonly type: "bumpSequenceSuccess";
    toXdrObject(): Extract<BumpSequenceResultWire, {
        code: 0;
    }>;
}
export declare class BumpSequenceResultBadSeq extends BumpSequenceResultBase {
    readonly type: "bumpSequenceBadSeq";
    toXdrObject(): Extract<BumpSequenceResultWire, {
        code: -1;
    }>;
}
export type BumpSequenceResult = BumpSequenceResultSuccess | BumpSequenceResultBadSeq;
export declare const BumpSequenceResult: typeof BumpSequenceResultBase;
export {};
