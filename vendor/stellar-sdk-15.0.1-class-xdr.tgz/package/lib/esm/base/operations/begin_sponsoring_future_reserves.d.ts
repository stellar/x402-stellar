import { Operation } from "../../xdr/index.js";
import { BeginSponsoringFutureReservesOpts } from "./types.js";
/**
 * Create a "begin sponsoring future reserves" operation.
 * @param opts - Options object
 * @param opts.sponsoredId - The sponsored account id.
 * @param opts.source - The source account for the operation. Defaults to the transaction's source account.
 *
 * @example
 * const op = Operation.beginSponsoringFutureReserves({
 *   sponsoredId: 'GDGU5OAPHNPU5UCLE5RDJHG7PXZFQYWKCFOEXSXNMR6KRQRI5T6XXCD7'
 * });
 *
 */
export declare function beginSponsoringFutureReserves(opts: BeginSponsoringFutureReservesOpts): Operation;
