import { Operation } from "../../xdr/index.js";
import { PaymentOpts } from "./types.js";
/**
 * Create a payment operation.
 *
 * @see https://developers.stellar.org/docs/start/list-of-operations/#payment
 *
 * @param opts - options object
 * @param opts.destination - destination account ID
 * @param opts.asset - asset to send
 * @param opts.amount - amount to send
 * @param opts.source - The source account for the payment.
 *     Defaults to the transaction's source account.
 */
export declare function payment(opts: PaymentOpts): Operation;
