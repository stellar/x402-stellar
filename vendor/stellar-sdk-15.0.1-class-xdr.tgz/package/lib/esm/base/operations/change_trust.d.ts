import { Operation } from "../../xdr/index.js";
import { ChangeTrustOpts } from "./types.js";
/**
 * A "change trust" operation adds, removes, or updates a trust line for a
 * given asset from the source account to another.
 *
 * @param opts - Options object
 * @param opts.asset - The asset for the trust line.
 * @param opts.limit - The limit for the asset, defaults to max int64.
 *                     If the limit is set to "0" it deletes the trustline.
 * @param opts.source - The source account (defaults to transaction source).
 */
export declare function changeTrust(opts: ChangeTrustOpts): Operation;
