import { Operation } from "../../xdr/index.js";
import { ManageDataOpts } from "./types.js";
/**
 * This operation adds data entry to the ledger.
 * @param opts - Options object
 * @param opts.name - The name of the data entry.
 * @param opts.value - The value of the data entry.
 * @param opts.source - The optional source account.
 */
export declare function manageData(opts: ManageDataOpts): Operation;
