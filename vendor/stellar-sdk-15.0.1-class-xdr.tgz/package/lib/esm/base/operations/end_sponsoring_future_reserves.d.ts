import { Operation } from "../../xdr/index.js";
import { EndSponsoringFutureReservesOpts } from "./types.js";
/**
 * Create an "end sponsoring future reserves" operation.
 * @param opts - Options object
 * @param opts.source - The source account for the operation. Defaults to the transaction's source account.
 *
 * @example
 * const op = Operation.endSponsoringFutureReserves();
 *
 */
export declare function endSponsoringFutureReserves(opts?: EndSponsoringFutureReservesOpts): Operation;
